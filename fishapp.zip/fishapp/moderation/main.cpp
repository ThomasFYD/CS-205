#include <iostream>
#include "moderation_manager.h"
#include "moderator.h"
using namespace std;

int main()
{
//    db_access myDb;
//    moderation_manager myModManager(myDb);
//    auth_manager myManager(myDb);

//    myManager.createUser("Leko", "Levan", "Andghuladze",
//                         "lekolukagmail.com", QDate::currentDate().toString(), "nasidzegang", 6000);

//    cout << myModManager.assignModerator(6000) << endl;

//    cout << myModManager.checkModerator(6000) << endl;

//    cout << myModManager.authenticateModerator("Leko", "nasidzegang") << endl;




}
