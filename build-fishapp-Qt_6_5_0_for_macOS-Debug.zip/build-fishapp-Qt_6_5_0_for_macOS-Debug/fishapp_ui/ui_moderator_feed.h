/********************************************************************************
** Form generated from reading UI file 'moderator_feed.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODERATOR_FEED_H
#define UI_MODERATOR_FEED_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_moderator_feed
{
public:
    QFrame *line_8;
    QLabel *reasonLabel;
    QFrame *line;
    QFrame *line_3;
    QPushButton *pushButton_8;
    QLabel *label_5;
    QLabel *postLabel;
    QFrame *line_2;
    QLabel *post_profilePicture;
    QPushButton *previousButton;
    QPushButton *nextButton;
    QLabel *post_title;
    QFrame *line_4;
    QTextEdit *decisionEdit;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *banUserButton;
    QPushButton *removePostButton;
    QPushButton *shadowbanButton;
    QPushButton *suspendButton;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QLabel *reportIDLabel;
    QLabel *timeLabel;
    QLabel *reporterIDLabel;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QLabel *modIDLabel;
    QLabel *modFullLabel;
    QLabel *modUsernameLabel;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_3;
    QLabel *userIDLabel;
    QLabel *label;

    void setupUi(QDialog *moderator_feed)
    {
        if (moderator_feed->objectName().isEmpty())
            moderator_feed->setObjectName("moderator_feed");
        moderator_feed->resize(817, 600);
        moderator_feed->setMinimumSize(QSize(0, 0));
        moderator_feed->setMaximumSize(QSize(950, 600));
        line_8 = new QFrame(moderator_feed);
        line_8->setObjectName("line_8");
        line_8->setGeometry(QRect(80, 790, 611, 16));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);
        reasonLabel = new QLabel(moderator_feed);
        reasonLabel->setObjectName("reasonLabel");
        reasonLabel->setGeometry(QRect(150, 380, 611, 41));
        reasonLabel->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        line = new QFrame(moderator_feed);
        line->setObjectName("line");
        line->setGeometry(QRect(120, 50, 16, 401));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(moderator_feed);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(130, 40, 671, 16));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        pushButton_8 = new QPushButton(moderator_feed);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(20, 420, 83, 29));
        label_5 = new QLabel(moderator_feed);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(10, 0, 63, 61));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/admin-sign-laptop-icon-stock-vector-166205404.jpg")));
        label_5->setScaledContents(true);
        postLabel = new QLabel(moderator_feed);
        postLabel->setObjectName("postLabel");
        postLabel->setGeometry(QRect(140, 210, 611, 161));
        postLabel->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        line_2 = new QFrame(moderator_feed);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(780, 50, 16, 401));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        post_profilePicture = new QLabel(moderator_feed);
        post_profilePicture->setObjectName("post_profilePicture");
        post_profilePicture->setGeometry(QRect(140, 70, 141, 131));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(post_profilePicture->sizePolicy().hasHeightForWidth());
        post_profilePicture->setSizePolicy(sizePolicy);
        post_profilePicture->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        post_profilePicture->setScaledContents(true);
        previousButton = new QPushButton(moderator_feed);
        previousButton->setObjectName("previousButton");
        previousButton->setGeometry(QRect(260, 550, 83, 29));
        nextButton = new QPushButton(moderator_feed);
        nextButton->setObjectName("nextButton");
        nextButton->setGeometry(QRect(610, 550, 83, 29));
        post_title = new QLabel(moderator_feed);
        post_title->setObjectName("post_title");
        post_title->setGeometry(QRect(290, 150, 441, 41));
        QFont font;
        font.setPointSize(16);
        post_title->setFont(font);
        line_4 = new QFrame(moderator_feed);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(120, 370, 671, 16));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        decisionEdit = new QTextEdit(moderator_feed);
        decisionEdit->setObjectName("decisionEdit");
        decisionEdit->setGeometry(QRect(150, 480, 611, 61));
        layoutWidget = new QWidget(moderator_feed);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(150, 430, 611, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        banUserButton = new QPushButton(layoutWidget);
        banUserButton->setObjectName("banUserButton");

        horizontalLayout->addWidget(banUserButton);

        removePostButton = new QPushButton(layoutWidget);
        removePostButton->setObjectName("removePostButton");

        horizontalLayout->addWidget(removePostButton);

        shadowbanButton = new QPushButton(layoutWidget);
        shadowbanButton->setObjectName("shadowbanButton");

        horizontalLayout->addWidget(shadowbanButton);

        suspendButton = new QPushButton(layoutWidget);
        suspendButton->setObjectName("suspendButton");

        horizontalLayout->addWidget(suspendButton);

        layoutWidget1 = new QWidget(moderator_feed);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(590, 60, 181, 76));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        reportIDLabel = new QLabel(layoutWidget1);
        reportIDLabel->setObjectName("reportIDLabel");

        verticalLayout->addWidget(reportIDLabel);

        timeLabel = new QLabel(layoutWidget1);
        timeLabel->setObjectName("timeLabel");

        verticalLayout->addWidget(timeLabel);

        reporterIDLabel = new QLabel(layoutWidget1);
        reporterIDLabel->setObjectName("reporterIDLabel");

        verticalLayout->addWidget(reporterIDLabel);

        widget = new QWidget(moderator_feed);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(10, 70, 101, 111));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        modIDLabel = new QLabel(widget);
        modIDLabel->setObjectName("modIDLabel");

        verticalLayout_2->addWidget(modIDLabel);

        modFullLabel = new QLabel(widget);
        modFullLabel->setObjectName("modFullLabel");

        verticalLayout_2->addWidget(modFullLabel);

        modUsernameLabel = new QLabel(widget);
        modUsernameLabel->setObjectName("modUsernameLabel");

        verticalLayout_2->addWidget(modUsernameLabel);

        widget1 = new QWidget(moderator_feed);
        widget1->setObjectName("widget1");
        widget1->setGeometry(QRect(290, 80, 291, 49));
        verticalLayout_3 = new QVBoxLayout(widget1);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        userIDLabel = new QLabel(widget1);
        userIDLabel->setObjectName("userIDLabel");

        verticalLayout_3->addWidget(userIDLabel);

        label = new QLabel(widget1);
        label->setObjectName("label");

        verticalLayout_3->addWidget(label);


        retranslateUi(moderator_feed);

        QMetaObject::connectSlotsByName(moderator_feed);
    } // setupUi

    void retranslateUi(QDialog *moderator_feed)
    {
        moderator_feed->setWindowTitle(QCoreApplication::translate("moderator_feed", "Dialog", nullptr));
        reasonLabel->setText(QString());
        pushButton_8->setText(QCoreApplication::translate("moderator_feed", "Logout", nullptr));
        label_5->setText(QString());
        postLabel->setText(QCoreApplication::translate("moderator_feed", "NO REPORTS", nullptr));
        post_profilePicture->setText(QString());
        previousButton->setText(QCoreApplication::translate("moderator_feed", "Previous", nullptr));
        nextButton->setText(QCoreApplication::translate("moderator_feed", "Next", nullptr));
        post_title->setText(QCoreApplication::translate("moderator_feed", "NO REPORTS", nullptr));
        banUserButton->setText(QCoreApplication::translate("moderator_feed", "Ban User", nullptr));
        removePostButton->setText(QCoreApplication::translate("moderator_feed", "Remove Post", nullptr));
        shadowbanButton->setText(QCoreApplication::translate("moderator_feed", "Shadowban", nullptr));
        suspendButton->setText(QCoreApplication::translate("moderator_feed", "Suspend", nullptr));
        reportIDLabel->setText(QCoreApplication::translate("moderator_feed", "ReportID:", nullptr));
        timeLabel->setText(QCoreApplication::translate("moderator_feed", "Time:", nullptr));
        reporterIDLabel->setText(QCoreApplication::translate("moderator_feed", "Reporter: #", nullptr));
        modIDLabel->setText(QCoreApplication::translate("moderator_feed", "Admin", nullptr));
        modFullLabel->setText(QCoreApplication::translate("moderator_feed", "Full Name", nullptr));
        modUsernameLabel->setText(QCoreApplication::translate("moderator_feed", "@username", nullptr));
        userIDLabel->setText(QCoreApplication::translate("moderator_feed", "User #", nullptr));
        label->setText(QCoreApplication::translate("moderator_feed", "Post #", nullptr));
    } // retranslateUi

};

namespace Ui {
    class moderator_feed: public Ui_moderator_feed {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODERATOR_FEED_H
