/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *loginUserButton;
    QPushButton *anonUserButton;
    QPushButton *createAccount;
    QPushButton *loginModeratorButton;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(310, 410);
        MainWindow->setMinimumSize(QSize(0, 0));
        MainWindow->setMaximumSize(QSize(310, 410));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(80, 70, 146, 20));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(50, 100, 211, 281));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        loginUserButton = new QPushButton(layoutWidget);
        loginUserButton->setObjectName("loginUserButton");

        verticalLayout->addWidget(loginUserButton);

        anonUserButton = new QPushButton(layoutWidget);
        anonUserButton->setObjectName("anonUserButton");

        verticalLayout->addWidget(anonUserButton);

        createAccount = new QPushButton(layoutWidget);
        createAccount->setObjectName("createAccount");

        verticalLayout->addWidget(createAccount);

        loginModeratorButton = new QPushButton(layoutWidget);
        loginModeratorButton->setObjectName("loginModeratorButton");

        verticalLayout->addWidget(loginModeratorButton);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Welcome To FishFlow!", nullptr));
        loginUserButton->setText(QCoreApplication::translate("MainWindow", "Log in as a User", nullptr));
        anonUserButton->setText(QCoreApplication::translate("MainWindow", "Browse Anonymously", nullptr));
        createAccount->setText(QCoreApplication::translate("MainWindow", "Create a new Account", nullptr));
        loginModeratorButton->setText(QCoreApplication::translate("MainWindow", "Log in as a Moderator", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
