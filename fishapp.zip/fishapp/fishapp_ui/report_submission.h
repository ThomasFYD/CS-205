#ifndef REPORT_SUBMISSION_H
#define REPORT_SUBMISSION_H

#include <QDialog>
#include <QMessageBox>
#include "../authentication_engine/user.h"

namespace Ui {
class report_submission;
}

class report_submission : public QDialog
{
    Q_OBJECT

public:
    explicit report_submission(user* user, int postId, QWidget *parent = nullptr); // Update the constructor
    ~report_submission();

private slots:
    void on_submitButtom_clicked();

    void on_cancelButton_clicked();

private:
    Ui::report_submission *ui;
    user* m_user; // Add a member variable for the user
    int m_postId; // Add a member variable for the post ID
};

#endif // REPORT_SUBMISSION_H
