#ifndef MODERATOR_H
#define MODERATOR_H

#include "../authentication_engine/user.h"
#include "../db/db_access.h"
#include "../post/one_post.h"
#include <QObject>
#include <QString>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <string>

class moderator : public user, public QObject {
public:
    moderator(int user_id, const QString &username, const QString &first_name,
              const QString &last_name, const QString &email,
              const QString &date_of_registration, db_access &db);

    moderator();

    int getModeratorId() const;

    bool removePost(int post_id, const QString &removal_reason);
    bool shadowBanUser(int user_id);
    bool unshadowBanUser(int user_id);
    bool putUserInJail(int user_id, int jail_duration, const QString &jail_reason);
    bool releaseUserFromJail(int user_id);
    bool removeUser(int user_id, const QString &removal_reason);
    bool reviewReport(int report_id, bool is_valid);

//signals:
//    void postRemoved(int post_id);
//    void userRemoved(int user_id);

private:
    int moderator_id;
    int user_id;
    db_access &db;

    // Helper functions for the moderation actions
    bool isUserValid(int user_id);
    bool isPostValid(int post_id);
    bool isReportValid(int report_id);
};

#endif // MODERATOR_H
