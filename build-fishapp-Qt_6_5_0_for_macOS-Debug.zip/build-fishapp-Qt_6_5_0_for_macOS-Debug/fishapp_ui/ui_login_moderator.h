/********************************************************************************
** Form generated from reading UI file 'login_moderator.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_MODERATOR_H
#define UI_LOGIN_MODERATOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login_moderator
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *submitButton;
    QPushButton *cancelButton;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QFormLayout *formLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLabel *label_3;
    QVBoxLayout *verticalLayout;
    QLineEdit *usernameEdit;
    QLineEdit *passwordEdit;

    void setupUi(QDialog *login_moderator)
    {
        if (login_moderator->objectName().isEmpty())
            login_moderator->setObjectName("login_moderator");
        login_moderator->resize(310, 210);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(login_moderator->sizePolicy().hasHeightForWidth());
        login_moderator->setSizePolicy(sizePolicy);
        login_moderator->setMinimumSize(QSize(310, 210));
        layoutWidget = new QWidget(login_moderator);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(90, 150, 169, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        submitButton = new QPushButton(layoutWidget);
        submitButton->setObjectName("submitButton");

        horizontalLayout->addWidget(submitButton);

        cancelButton = new QPushButton(layoutWidget);
        cancelButton->setObjectName("cancelButton");

        horizontalLayout->addWidget(cancelButton);

        layoutWidget_2 = new QWidget(login_moderator);
        layoutWidget_2->setObjectName("layoutWidget_2");
        layoutWidget_2->setGeometry(QRect(50, 30, 206, 96));
        verticalLayout_3 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget_2);
        label->setObjectName("label");
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        formLayout = new QFormLayout();
        formLayout->setObjectName("formLayout");
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName("label_2");

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(layoutWidget_2);
        label_3->setObjectName("label_3");

        verticalLayout_2->addWidget(label_3);


        formLayout->setLayout(0, QFormLayout::LabelRole, verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        usernameEdit = new QLineEdit(layoutWidget_2);
        usernameEdit->setObjectName("usernameEdit");

        verticalLayout->addWidget(usernameEdit);

        passwordEdit = new QLineEdit(layoutWidget_2);
        passwordEdit->setObjectName("passwordEdit");

        verticalLayout->addWidget(passwordEdit);


        formLayout->setLayout(0, QFormLayout::FieldRole, verticalLayout);


        verticalLayout_3->addLayout(formLayout);


        retranslateUi(login_moderator);

        QMetaObject::connectSlotsByName(login_moderator);
    } // setupUi

    void retranslateUi(QDialog *login_moderator)
    {
        login_moderator->setWindowTitle(QCoreApplication::translate("login_moderator", "Dialog", nullptr));
        submitButton->setText(QCoreApplication::translate("login_moderator", "Submit", nullptr));
        cancelButton->setText(QCoreApplication::translate("login_moderator", "Cancel", nullptr));
        label->setText(QCoreApplication::translate("login_moderator", "Welcome Back, Admin!", nullptr));
        label_2->setText(QCoreApplication::translate("login_moderator", "Username", nullptr));
        label_3->setText(QCoreApplication::translate("login_moderator", "Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class login_moderator: public Ui_login_moderator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_MODERATOR_H
