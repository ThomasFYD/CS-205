/********************************************************************************
** Form generated from reading UI file 'user_profile.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USER_PROFILE_H
#define UI_USER_PROFILE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_user_profile
{
public:
    QLabel *label_11;
    QLabel *user_fullname;
    QLabel *user_username;
    QLabel *post_hashtags;
    QTextEdit *content;
    QFrame *line;
    QLabel *post_title;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_5;
    QLabel *post_timestamp;
    QLabel *post_username;
    QFrame *line_9;
    QLabel *post_fullname;
    QLabel *label_15;
    QPushButton *delete_post;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *log_out;
    QPushButton *settings;
    QPushButton *profile;
    QPushButton *feed;
    QPushButton *messages;
    QFrame *line_11;
    QFrame *line_10;
    QFrame *line_12;
    QPushButton *previous_post;
    QPushButton *next_post;
    QLabel *post_content;
    QLabel *user_interests;

    void setupUi(QDialog *user_profile)
    {
        if (user_profile->objectName().isEmpty())
            user_profile->setObjectName("user_profile");
        user_profile->resize(928, 731);
        label_11 = new QLabel(user_profile);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(120, 80, 151, 151));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        user_fullname = new QLabel(user_profile);
        user_fullname->setObjectName("user_fullname");
        user_fullname->setGeometry(QRect(290, 110, 261, 20));
        QFont font;
        font.setPointSize(12);
        user_fullname->setFont(font);
        user_username = new QLabel(user_profile);
        user_username->setObjectName("user_username");
        user_username->setGeometry(QRect(290, 80, 251, 20));
        post_hashtags = new QLabel(user_profile);
        post_hashtags->setObjectName("post_hashtags");
        post_hashtags->setGeometry(QRect(260, 360, 191, 20));
        content = new QTextEdit(user_profile);
        content->setObjectName("content");
        content->setGeometry(QRect(50, 380, 551, 161));
        line = new QFrame(user_profile);
        line->setObjectName("line");
        line->setGeometry(QRect(170, 300, 611, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        post_title = new QLabel(user_profile);
        post_title->setObjectName("post_title");
        post_title->setGeometry(QRect(200, 380, 501, 41));
        QFont font1;
        font1.setPointSize(16);
        post_title->setFont(font1);
        line_2 = new QFrame(user_profile);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(170, 580, 611, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(user_profile);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(160, 310, 20, 281));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_5 = new QFrame(user_profile);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(770, 310, 20, 281));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        post_timestamp = new QLabel(user_profile);
        post_timestamp->setObjectName("post_timestamp");
        post_timestamp->setGeometry(QRect(590, 360, 171, 20));
        post_username = new QLabel(user_profile);
        post_username->setObjectName("post_username");
        post_username->setGeometry(QRect(260, 340, 221, 20));
        line_9 = new QFrame(user_profile);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(140, 280, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        post_fullname = new QLabel(user_profile);
        post_fullname->setObjectName("post_fullname");
        post_fullname->setGeometry(QRect(260, 320, 231, 20));
        label_15 = new QLabel(user_profile);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(190, 320, 61, 61));
        label_15->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_15->setScaledContents(true);
        delete_post = new QPushButton(user_profile);
        delete_post->setObjectName("delete_post");
        delete_post->setGeometry(QRect(680, 320, 83, 29));
        pushButton_3 = new QPushButton(user_profile);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(680, 110, 121, 29));
        pushButton_4 = new QPushButton(user_profile);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(680, 160, 121, 29));
        log_out = new QPushButton(user_profile);
        log_out->setObjectName("log_out");
        log_out->setGeometry(QRect(720, 700, 83, 29));
        settings = new QPushButton(user_profile);
        settings->setObjectName("settings");
        settings->setGeometry(QRect(770, 70, 31, 29));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../database/pictures/Ic_settings_48px.svg.png"), QSize(), QIcon::Normal, QIcon::Off);
        settings->setIcon(icon);
        settings->setCheckable(false);
        profile = new QPushButton(user_profile);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(700, 20, 100, 32));
        feed = new QPushButton(user_profile);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(140, 20, 100, 32));
        messages = new QPushButton(user_profile);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(420, 19, 100, 32));
        messages->setFlat(false);
        line_11 = new QFrame(user_profile);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(810, 0, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        line_10 = new QFrame(user_profile);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(130, 0, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        line_12 = new QFrame(user_profile);
        line_12->setObjectName("line_12");
        line_12->setGeometry(QRect(130, 50, 681, 31));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        previous_post = new QPushButton(user_profile);
        previous_post->setObjectName("previous_post");
        previous_post->setGeometry(QRect(320, 620, 100, 32));
        next_post = new QPushButton(user_profile);
        next_post->setObjectName("next_post");
        next_post->setGeometry(QRect(520, 620, 100, 32));
        post_content = new QLabel(user_profile);
        post_content->setObjectName("post_content");
        post_content->setGeometry(QRect(200, 420, 541, 131));
        user_interests = new QLabel(user_profile);
        user_interests->setObjectName("user_interests");
        user_interests->setGeometry(QRect(290, 150, 191, 16));

        retranslateUi(user_profile);

        messages->setDefault(false);


        QMetaObject::connectSlotsByName(user_profile);
    } // setupUi

    void retranslateUi(QDialog *user_profile)
    {
        user_profile->setWindowTitle(QCoreApplication::translate("user_profile", "Dialog", nullptr));
        label_11->setText(QString());
        user_fullname->setText(QString());
        user_username->setText(QString());
        post_hashtags->setText(QCoreApplication::translate("user_profile", "Interests: Tanks", nullptr));
        content->setHtml(QString());
        post_title->setText(QString());
        post_timestamp->setText(QString());
        post_username->setText(QString());
        post_fullname->setText(QString());
        label_15->setText(QString());
        delete_post->setText(QCoreApplication::translate("user_profile", "Delete", nullptr));
        pushButton_3->setText(QCoreApplication::translate("user_profile", "Change Picture", nullptr));
        pushButton_4->setText(QCoreApplication::translate("user_profile", "Change Interests", nullptr));
        log_out->setText(QCoreApplication::translate("user_profile", "Log Out", nullptr));
        settings->setText(QString());
        profile->setText(QCoreApplication::translate("user_profile", "Profile", nullptr));
        feed->setText(QCoreApplication::translate("user_profile", "Feed", nullptr));
        messages->setText(QCoreApplication::translate("user_profile", "Messages", nullptr));
        previous_post->setText(QCoreApplication::translate("user_profile", "Previous", nullptr));
        next_post->setText(QCoreApplication::translate("user_profile", "Next", nullptr));
        post_content->setText(QString());
        user_interests->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class user_profile: public Ui_user_profile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USER_PROFILE_H
