#ifndef USER_FEED_H
#define USER_FEED_H
#include "../authentication_engine/auth_manager.h"
#include "../post/one_post.h"



class user_feed
{
public:
    user_feed(auth_manager& userAuthentication);//db_access& dbAccess, user& userAccess);

    // Method returning all the posts unordered in a vector.
    std::vector<one_post> all_posts();

    // Method returning all the posts sorted by hashtag relevancy first, then date.
    std::vector<one_post> posts_by_hashtag();

    // Method sorting the posts with respect to date.
    std::vector<one_post> sort(std::vector<one_post> initial);

    // Method returning information about the post from the database
    std::vector<std::string> findInformation(int postId);

    // Method retrieving all existent hashtags (unordered)
    std::vector<std::string> all_hashtags();




private:
    // Method that compares two posts to determine which should come first.
    bool compare(one_post first, one_post second);

    // Method comparing posts purely by date.
    bool compare_date(one_post first, one_post second);
    int year(one_post data);
    int month(one_post data);
    int date(one_post data);
    int hours(one_post data);
    int minutes(one_post data);
    int seconds(one_post data);

//    db_access& m_dbAccess;
//    user& myUser;
    auth_manager& myAuthentication;

};

#endif // USER_FEED_H
