#ifndef FEATURES_H
#define FEATURES_H


class features
{
public:
    features();
};

#endif // FEATURES_H
