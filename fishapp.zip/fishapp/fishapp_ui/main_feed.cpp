#include "main_feed.h"
#include "create_post.h"
#include "report_submission.h"
#include "ui_main_feed.h"
#include "user_profile.h"


main_feed::main_feed(QMainWindow* mainWindow, auth_manager& userAuthenticaiton, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::main_feed),
    currentUser(userAuthenticaiton.getCurrentUser()),
    myFeed(userAuthenticaiton),
    myManager(userAuthenticaiton),
    mainWindow(mainWindow)
{
    ui->setupUi(this);
    ui->username->setText("@" + currentUser->getUsername());
    ui->fullName->setText(currentUser->getFirstName() + " " + currentUser->getLastName());
    myPosts = myFeed.posts_by_hashtag();
    if(myPosts.size()<1){
        position = -1;
    }
    else{
        position = 0;
        this->load_post();
    }
}

main_feed::~main_feed()
{
    delete currentUser;
    delete ui;
}

//takes you to top of feed
void main_feed::on_feed_clicked()
{
    if(position != -1){
        position = 0;
        this->load_post();
    }
}


void main_feed::on_messages_clicked()
{
    //takes you to messages
}


void main_feed::on_profile_clicked()
{
    user_profile* userProfile = new user_profile(mainWindow, this, myManager);
    userProfile->show();
    this->hide();
}



void main_feed::load_post(){
    if(position!=-1){
        std::vector<std::string> info = myFeed.findInformation(myPosts.at(position).return_postId());
        std::string hashtags;
        for(int i = 3; i < info.size(); i++){
            hashtags += info.at(i) + " ";
        }
        ui->post_fullName->setText(QString::fromStdString(info.at(1) + " " + info.at(2)));
        ui->post_content->setText(myPosts.at(position).return_content());       
        ui->post_hashtag->setText(QString::fromStdString(hashtags));
        ui->post_username->setText("@" + QString::fromStdString(info.at(0)));
        ui->post_timestamp->setText(myPosts.at(position).return_timestamp());
        ui->post_title->setText(myPosts.at(position).return_title());
    }
}


void main_feed::on_log_out_clicked()
{
    myManager.logout();
    this->close();
    mainWindow->show();
}


void main_feed::on_create_post_clicked()
{
    create_post *createPostDialog = new create_post(myManager, this);
    createPostDialog->show();
    connect(createPostDialog, &create_post::postCreated, this, &main_feed::updateFeed);
    connect(createPostDialog, &create_post::finished, createPostDialog, &create_post::deleteLater);
}


void main_feed::on_search_hashtag_clicked()
{
    //takes you to hashtag search
}


void main_feed::on_previous_post_clicked()
{
    if(position > 0){
        position = position - 1;
        this->load_post();
    }  
}


void main_feed::on_next_post_clicked()
{
    if(position < myPosts.size() - 1){
        position = position + 1;
        this->load_post();
    }
}


void main_feed::on_report_clicked()
{
    report_submission *reportDialog = new report_submission(currentUser, myPosts.at(position).return_postId(), this);
    reportDialog->show();
    connect(reportDialog, &report_submission::finished, reportDialog, &report_submission::deleteLater);
}

void main_feed::updateFeed() {
    myPosts = myFeed.all_posts();
    if (myPosts.size() < 1) {
        position = -1;
    } else {
        position = 0;
        this->load_post();
    }
}


