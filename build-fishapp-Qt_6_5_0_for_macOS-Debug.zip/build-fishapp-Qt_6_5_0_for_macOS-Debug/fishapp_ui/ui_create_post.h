/********************************************************************************
** Form generated from reading UI file 'create_post.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATE_POST_H
#define UI_CREATE_POST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include "checkablecombobox.h"

QT_BEGIN_NAMESPACE

class Ui_create_post
{
public:
    QTextEdit *textEdit;
    QLineEdit *titleEdit;
    QLabel *label;
    QLabel *label_2;
    checkableComboBox *interestsBox;
    QLabel *label_3;
    QPushButton *postButton;
    QPushButton *cancelButton;
    QLabel *nameLabel;
    QLabel *usernameLabel;
    QLabel *totalPostsLabel;
    QLabel *label_4;
    QTextEdit *customEdit;
    QPushButton *addButton;

    void setupUi(QDialog *create_post)
    {
        if (create_post->objectName().isEmpty())
            create_post->setObjectName("create_post");
        create_post->resize(632, 456);
        textEdit = new QTextEdit(create_post);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(130, 200, 461, 201));
        titleEdit = new QLineEdit(create_post);
        titleEdit->setObjectName("titleEdit");
        titleEdit->setGeometry(QRect(130, 120, 461, 28));
        label = new QLabel(create_post);
        label->setObjectName("label");
        label->setGeometry(QRect(130, 80, 63, 20));
        label_2 = new QLabel(create_post);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(130, 170, 63, 20));
        interestsBox = new checkableComboBox(create_post);
        interestsBox->setObjectName("interestsBox");
        interestsBox->setGeometry(QRect(210, 40, 151, 28));
        label_3 = new QLabel(create_post);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(130, 40, 63, 20));
        postButton = new QPushButton(create_post);
        postButton->setObjectName("postButton");
        postButton->setGeometry(QRect(430, 410, 83, 29));
        cancelButton = new QPushButton(create_post);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setGeometry(QRect(530, 410, 83, 29));
        nameLabel = new QLabel(create_post);
        nameLabel->setObjectName("nameLabel");
        nameLabel->setGeometry(QRect(10, 140, 91, 20));
        usernameLabel = new QLabel(create_post);
        usernameLabel->setObjectName("usernameLabel");
        usernameLabel->setGeometry(QRect(10, 170, 111, 20));
        totalPostsLabel = new QLabel(create_post);
        totalPostsLabel->setObjectName("totalPostsLabel");
        totalPostsLabel->setGeometry(QRect(10, 210, 101, 20));
        label_4 = new QLabel(create_post);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(10, 30, 101, 91));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        label_4->setScaledContents(true);
        customEdit = new QTextEdit(create_post);
        customEdit->setObjectName("customEdit");
        customEdit->setGeometry(QRect(460, 40, 141, 31));
        addButton = new QPushButton(create_post);
        addButton->setObjectName("addButton");
        addButton->setGeometry(QRect(510, 80, 91, 31));

        retranslateUi(create_post);

        QMetaObject::connectSlotsByName(create_post);
    } // setupUi

    void retranslateUi(QDialog *create_post)
    {
        create_post->setWindowTitle(QCoreApplication::translate("create_post", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("create_post", "Title:", nullptr));
        label_2->setText(QCoreApplication::translate("create_post", "Contents:", nullptr));
        label_3->setText(QCoreApplication::translate("create_post", "Interests:", nullptr));
        postButton->setText(QCoreApplication::translate("create_post", "Post", nullptr));
        cancelButton->setText(QCoreApplication::translate("create_post", "Cancel", nullptr));
        nameLabel->setText(QCoreApplication::translate("create_post", "Salty Steve", nullptr));
        usernameLabel->setText(QCoreApplication::translate("create_post", "@humanefisher", nullptr));
        totalPostsLabel->setText(QCoreApplication::translate("create_post", "Total posts: 17", nullptr));
        label_4->setText(QString());
        customEdit->setPlaceholderText(QCoreApplication::translate("create_post", "Custom Hashtag", nullptr));
        addButton->setText(QCoreApplication::translate("create_post", "Add", nullptr));
    } // retranslateUi

};

namespace Ui {
    class create_post: public Ui_create_post {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATE_POST_H
