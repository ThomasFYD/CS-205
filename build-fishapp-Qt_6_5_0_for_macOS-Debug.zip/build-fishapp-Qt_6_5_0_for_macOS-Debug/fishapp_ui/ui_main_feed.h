/********************************************************************************
** Form generated from reading UI file 'main_feed.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_FEED_H
#define UI_MAIN_FEED_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_main_feed
{
public:
    QPushButton *create_post;
    QFrame *line_2;
    QLabel *post_title;
    QPushButton *messages;
    QPushButton *feed;
    QPushButton *log_out;
    QLabel *username;
    QPushButton *search_hashtag;
    QPushButton *profile;
    QLabel *post_timestamp;
    QFrame *line_11;
    QLabel *post_profilePicture;
    QFrame *line;
    QLabel *fullName;
    QFrame *line_5;
    QPushButton *report;
    QFrame *line_9;
    QFrame *line_10;
    QFrame *line_3;
    QLabel *post_content;
    QPushButton *previous_post;
    QPushButton *next_post;
    QLabel *post_profilePicture_2;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *post_fullName;
    QLabel *post_username;
    QLabel *post_hashtag;

    void setupUi(QDialog *main_feed)
    {
        if (main_feed->objectName().isEmpty())
            main_feed->setObjectName("main_feed");
        main_feed->resize(950, 525);
        main_feed->setMinimumSize(QSize(950, 525));
        main_feed->setMaximumSize(QSize(950, 525));
        create_post = new QPushButton(main_feed);
        create_post->setObjectName("create_post");
        create_post->setGeometry(QRect(70, 280, 111, 29));
        line_2 = new QFrame(main_feed);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(220, 450, 611, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        post_title = new QLabel(main_feed);
        post_title->setObjectName("post_title");
        post_title->setGeometry(QRect(380, 250, 441, 41));
        QFont font;
        font.setPointSize(16);
        post_title->setFont(font);
        messages = new QPushButton(main_feed);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(490, 69, 100, 32));
        messages->setFlat(false);
        feed = new QPushButton(main_feed);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(210, 70, 100, 32));
        log_out = new QPushButton(main_feed);
        log_out->setObjectName("log_out");
        log_out->setGeometry(QRect(70, 380, 111, 29));
        username = new QLabel(main_feed);
        username->setObjectName("username");
        username->setGeometry(QRect(40, 230, 171, 20));
        search_hashtag = new QPushButton(main_feed);
        search_hashtag->setObjectName("search_hashtag");
        search_hashtag->setGeometry(QRect(70, 330, 111, 29));
        profile = new QPushButton(main_feed);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(770, 70, 100, 32));
        post_timestamp = new QLabel(main_feed);
        post_timestamp->setObjectName("post_timestamp");
        post_timestamp->setGeometry(QRect(740, 200, 71, 20));
        line_11 = new QFrame(main_feed);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(880, 50, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        post_profilePicture = new QLabel(main_feed);
        post_profilePicture->setObjectName("post_profilePicture");
        post_profilePicture->setGeometry(QRect(230, 160, 141, 131));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(post_profilePicture->sizePolicy().hasHeightForWidth());
        post_profilePicture->setSizePolicy(sizePolicy);
        post_profilePicture->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        post_profilePicture->setScaledContents(true);
        line = new QFrame(main_feed);
        line->setObjectName("line");
        line->setGeometry(QRect(220, 140, 611, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        fullName = new QLabel(main_feed);
        fullName->setObjectName("fullName");
        fullName->setGeometry(QRect(40, 200, 171, 20));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        fullName->setFont(font1);
        line_5 = new QFrame(main_feed);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(820, 150, 20, 311));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        report = new QPushButton(main_feed);
        report->setObjectName("report");
        report->setGeometry(QRect(730, 160, 91, 31));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../database/pictures/1045119-200.png"), QSize(), QIcon::Normal, QIcon::Off);
        report->setIcon(icon);
        line_9 = new QFrame(main_feed);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(200, 100, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        line_10 = new QFrame(main_feed);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(200, 50, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(main_feed);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(210, 150, 20, 311));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        post_content = new QLabel(main_feed);
        post_content->setObjectName("post_content");
        post_content->setGeometry(QRect(230, 310, 581, 131));
        post_content->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        previous_post = new QPushButton(main_feed);
        previous_post->setObjectName("previous_post");
        previous_post->setGeometry(QRect(350, 470, 100, 32));
        next_post = new QPushButton(main_feed);
        next_post->setObjectName("next_post");
        next_post->setGeometry(QRect(590, 470, 100, 32));
        post_profilePicture_2 = new QLabel(main_feed);
        post_profilePicture_2->setObjectName("post_profilePicture_2");
        post_profilePicture_2->setGeometry(QRect(40, 50, 141, 121));
        sizePolicy.setHeightForWidth(post_profilePicture_2->sizePolicy().hasHeightForWidth());
        post_profilePicture_2->setSizePolicy(sizePolicy);
        post_profilePicture_2->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        post_profilePicture_2->setScaledContents(true);
        layoutWidget = new QWidget(main_feed);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(380, 160, 321, 91));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        post_fullName = new QLabel(layoutWidget);
        post_fullName->setObjectName("post_fullName");

        verticalLayout->addWidget(post_fullName);

        post_username = new QLabel(layoutWidget);
        post_username->setObjectName("post_username");

        verticalLayout->addWidget(post_username);

        post_hashtag = new QLabel(layoutWidget);
        post_hashtag->setObjectName("post_hashtag");

        verticalLayout->addWidget(post_hashtag);


        retranslateUi(main_feed);

        messages->setDefault(false);


        QMetaObject::connectSlotsByName(main_feed);
    } // setupUi

    void retranslateUi(QDialog *main_feed)
    {
        main_feed->setWindowTitle(QCoreApplication::translate("main_feed", "Dialog", nullptr));
        create_post->setText(QCoreApplication::translate("main_feed", "Create Post", nullptr));
        post_title->setText(QCoreApplication::translate("main_feed", "Title", nullptr));
        messages->setText(QCoreApplication::translate("main_feed", "Messages", nullptr));
        feed->setText(QCoreApplication::translate("main_feed", "Feed", nullptr));
        log_out->setText(QCoreApplication::translate("main_feed", "Log Out", nullptr));
        username->setText(QCoreApplication::translate("main_feed", "@humanefisher", nullptr));
        search_hashtag->setText(QCoreApplication::translate("main_feed", "Search Hashtags", nullptr));
        profile->setText(QCoreApplication::translate("main_feed", "Profile", nullptr));
        post_timestamp->setText(QString());
        post_profilePicture->setText(QString());
        fullName->setText(QCoreApplication::translate("main_feed", "PlaceHolder", nullptr));
        report->setText(QCoreApplication::translate("main_feed", "Report", nullptr));
        post_content->setText(QCoreApplication::translate("main_feed", "No posts detected", nullptr));
        previous_post->setText(QCoreApplication::translate("main_feed", "Previous", nullptr));
        next_post->setText(QCoreApplication::translate("main_feed", "Next", nullptr));
        post_profilePicture_2->setText(QString());
        post_fullName->setText(QCoreApplication::translate("main_feed", "Full Name", nullptr));
        post_username->setText(QCoreApplication::translate("main_feed", "@username", nullptr));
        post_hashtag->setText(QCoreApplication::translate("main_feed", "Hashtags", nullptr));
    } // retranslateUi

};

namespace Ui {
    class main_feed: public Ui_main_feed {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_FEED_H
