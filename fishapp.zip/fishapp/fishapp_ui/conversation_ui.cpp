#include "conversation_ui.h"
#include "ui_conversation_ui.h"
#include "user_profile.h"

conversation_ui::conversation_ui(QMainWindow* mainWindow,QWidget *parent, auth_manager& userAuthenticaiton) :
    QDialog(parent),
    currentUser(userAuthenticaiton.getCurrentUser()),
    myFeed(userAuthenticaiton),
    myConvo(userAuthenticaiton),
    myWindow(mainWindow),
    myManager(userAuthenticaiton),
    ui(new Ui::conversation_ui)
{
    ui->setupUi(this);
    ui->userName->setText("@" + currentUser->getUsername());
    ui->fullName->setText(currentUser->getFirstName() + " " + currentUser->getLastName());
    myConversations = myConvo.all_conversations();
    if(myConversations.size()<1){
        position = -1;
    }
    else{
        position = 0;
        userId2 = myConversations.at(0).return_user2Id();
        this->load_conversations();
    }
}

conversation_ui::~conversation_ui()
{
    delete ui;
}

void conversation_ui::on_messages_clicked() {
    // Handle the Messages button click event
}

void conversation_ui::on_profile_clicked() {
    user_profile* userProfile = new user_profile(myWindow, this, myManager);
    userProfile->show();
    this->hide();
}

void conversation_ui::on_feed_clicked() {
    main_feed* mainFeed = new main_feed(myWindow, myManager, this);
    mainFeed->show();
    this->hide();
}

void conversation_ui::on_next_clicked() {
    if(position < myConversations.size() - 1){
        position = position + 1;
        userId2 = myConversations.at(position).return_user2Id();
        this->load_conversations();
    }
}

void conversation_ui::on_previous_clicked() {
    if(position > 0){
        position = position - 1;
        userId2 = myConversations.at(position).return_user2Id();
        this->load_conversations();
    }
}

void conversation_ui::on_chat_clicked() {
    // Handle the Delete button click event for the first conversation
}

void conversation_ui::on_deleteButton_clicked() {
    myConvo.delete_conversation(userId2);
}

void conversation_ui::load_conversations(){
//    if(position!=-1){
//        ui->fullName->setText(userId2->getFirstName() + " " + currentUser->getLastName());
//        ui->username->setText("@" + userId2->getUsername());
//    }
}
