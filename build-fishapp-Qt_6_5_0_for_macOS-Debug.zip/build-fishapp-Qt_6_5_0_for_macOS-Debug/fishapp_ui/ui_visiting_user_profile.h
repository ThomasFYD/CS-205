/********************************************************************************
** Form generated from reading UI file 'visiting_user_profile.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VISITING_USER_PROFILE_H
#define UI_VISITING_USER_PROFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_visiting_user_profile
{
public:
    QWidget *centralwidget;
    QPushButton *previous_post;
    QPushButton *next_post;
    QLabel *label_11;
    QPushButton *feed;
    QPushButton *conversation;
    QFrame *line_12;
    QFrame *line_2;
    QLabel *label_15;
    QLabel *post_timestamp;
    QFrame *line_3;
    QFrame *line_10;
    QPushButton *report_post;
    QLabel *post_title;
    QPushButton *log_out;
    QLabel *user_interests;
    QLabel *user_fullname;
    QLabel *user_username;
    QFrame *line;
    QPushButton *profile;
    QFrame *line_5;
    QLabel *post_content;
    QPushButton *messages;
    QLabel *post_fullname;
    QFrame *line_11;
    QLabel *post_hashtags;
    QLabel *post_username;
    QFrame *line_9;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *visiting_user_profile)
    {
        if (visiting_user_profile->objectName().isEmpty())
            visiting_user_profile->setObjectName("visiting_user_profile");
        visiting_user_profile->resize(1015, 834);
        centralwidget = new QWidget(visiting_user_profile);
        centralwidget->setObjectName("centralwidget");
        previous_post = new QPushButton(centralwidget);
        previous_post->setObjectName("previous_post");
        previous_post->setGeometry(QRect(270, 640, 100, 32));
        next_post = new QPushButton(centralwidget);
        next_post->setObjectName("next_post");
        next_post->setGeometry(QRect(470, 640, 100, 32));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(70, 100, 151, 151));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        feed = new QPushButton(centralwidget);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(90, 40, 100, 32));
        conversation = new QPushButton(centralwidget);
        conversation->setObjectName("conversation");
        conversation->setGeometry(QRect(630, 100, 131, 29));
        line_12 = new QFrame(centralwidget);
        line_12->setObjectName("line_12");
        line_12->setGeometry(QRect(80, 70, 681, 31));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(120, 600, 611, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        label_15 = new QLabel(centralwidget);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(140, 340, 61, 61));
        label_15->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_15->setScaledContents(true);
        post_timestamp = new QLabel(centralwidget);
        post_timestamp->setObjectName("post_timestamp");
        post_timestamp->setGeometry(QRect(550, 380, 161, 20));
        line_3 = new QFrame(centralwidget);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(110, 330, 20, 281));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_10 = new QFrame(centralwidget);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(80, 20, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        report_post = new QPushButton(centralwidget);
        report_post->setObjectName("report_post");
        report_post->setGeometry(QRect(630, 340, 83, 29));
        post_title = new QLabel(centralwidget);
        post_title->setObjectName("post_title");
        post_title->setGeometry(QRect(150, 400, 541, 41));
        QFont font;
        font.setPointSize(16);
        post_title->setFont(font);
        log_out = new QPushButton(centralwidget);
        log_out->setObjectName("log_out");
        log_out->setGeometry(QRect(670, 720, 83, 29));
        user_interests = new QLabel(centralwidget);
        user_interests->setObjectName("user_interests");
        user_interests->setGeometry(QRect(240, 170, 221, 16));
        user_fullname = new QLabel(centralwidget);
        user_fullname->setObjectName("user_fullname");
        user_fullname->setGeometry(QRect(240, 130, 241, 20));
        QFont font1;
        font1.setPointSize(12);
        user_fullname->setFont(font1);
        user_username = new QLabel(centralwidget);
        user_username->setObjectName("user_username");
        user_username->setGeometry(QRect(240, 100, 261, 20));
        line = new QFrame(centralwidget);
        line->setObjectName("line");
        line->setGeometry(QRect(120, 320, 611, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        profile = new QPushButton(centralwidget);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(650, 40, 100, 32));
        line_5 = new QFrame(centralwidget);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(720, 330, 20, 281));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        post_content = new QLabel(centralwidget);
        post_content->setObjectName("post_content");
        post_content->setGeometry(QRect(150, 440, 541, 131));
        messages = new QPushButton(centralwidget);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(370, 39, 100, 32));
        messages->setFlat(false);
        post_fullname = new QLabel(centralwidget);
        post_fullname->setObjectName("post_fullname");
        post_fullname->setGeometry(QRect(210, 340, 271, 20));
        line_11 = new QFrame(centralwidget);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(760, 20, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        post_hashtags = new QLabel(centralwidget);
        post_hashtags->setObjectName("post_hashtags");
        post_hashtags->setGeometry(QRect(210, 380, 301, 20));
        post_username = new QLabel(centralwidget);
        post_username->setObjectName("post_username");
        post_username->setGeometry(QRect(210, 360, 231, 20));
        line_9 = new QFrame(centralwidget);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(90, 300, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        visiting_user_profile->setCentralWidget(centralwidget);
        menubar = new QMenuBar(visiting_user_profile);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1015, 37));
        visiting_user_profile->setMenuBar(menubar);
        statusbar = new QStatusBar(visiting_user_profile);
        statusbar->setObjectName("statusbar");
        visiting_user_profile->setStatusBar(statusbar);

        retranslateUi(visiting_user_profile);

        messages->setDefault(false);


        QMetaObject::connectSlotsByName(visiting_user_profile);
    } // setupUi

    void retranslateUi(QMainWindow *visiting_user_profile)
    {
        visiting_user_profile->setWindowTitle(QCoreApplication::translate("visiting_user_profile", "MainWindow", nullptr));
        previous_post->setText(QCoreApplication::translate("visiting_user_profile", "Previous", nullptr));
        next_post->setText(QCoreApplication::translate("visiting_user_profile", "Next", nullptr));
        label_11->setText(QString());
        feed->setText(QCoreApplication::translate("visiting_user_profile", "Feed", nullptr));
        conversation->setText(QCoreApplication::translate("visiting_user_profile", "Conversation", nullptr));
        label_15->setText(QString());
        post_timestamp->setText(QCoreApplication::translate("visiting_user_profile", "4/12/2023", nullptr));
        report_post->setText(QCoreApplication::translate("visiting_user_profile", "Report", nullptr));
        post_title->setText(QCoreApplication::translate("visiting_user_profile", "I bought a gigantic fish tank today!", nullptr));
        log_out->setText(QCoreApplication::translate("visiting_user_profile", "Log Out", nullptr));
        user_interests->setText(QCoreApplication::translate("visiting_user_profile", "Intersts:", nullptr));
        user_fullname->setText(QCoreApplication::translate("visiting_user_profile", "Salty Steve", nullptr));
        user_username->setText(QCoreApplication::translate("visiting_user_profile", "@humanefisher", nullptr));
        profile->setText(QCoreApplication::translate("visiting_user_profile", "Profile", nullptr));
        post_content->setText(QCoreApplication::translate("visiting_user_profile", "TextLabel", nullptr));
        messages->setText(QCoreApplication::translate("visiting_user_profile", "Messages", nullptr));
        post_fullname->setText(QCoreApplication::translate("visiting_user_profile", "Salty Steve", nullptr));
        post_hashtags->setText(QCoreApplication::translate("visiting_user_profile", "hashtags", nullptr));
        post_username->setText(QCoreApplication::translate("visiting_user_profile", "@humanefisher", nullptr));
    } // retranslateUi

};

namespace Ui {
    class visiting_user_profile: public Ui_visiting_user_profile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VISITING_USER_PROFILE_H
