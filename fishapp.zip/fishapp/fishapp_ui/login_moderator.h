#ifndef LOGIN_MODERATOR_H
#define LOGIN_MODERATOR_H

#include <QDialog>
#include "../moderation/moderation_manager.h"
#include "qmainwindow.h"
#include <QMessageBox>
#include <QRegularExpression>

namespace Ui {
class login_moderator;
}

class login_moderator : public QDialog
{
    Q_OBJECT

public:
    explicit login_moderator(moderation_manager& manager, QMainWindow* mainWindow, QWidget *parent = nullptr);
    ~login_moderator();

private slots:
    void on_cancelButton_clicked();
    void on_submitButton_clicked();

private:
    Ui::login_moderator *ui;
    moderation_manager& myManager;
    QMainWindow* mainWindow;
};

#endif // LOGIN_MODERATOR_H
