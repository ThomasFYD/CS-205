/********************************************************************************
** Form generated from reading UI file 'createuser.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEUSER_H
#define UI_CREATEUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "checkablecombobox.h"

QT_BEGIN_NAMESPACE

class Ui_createUser
{
public:
    QLabel *label;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *submitButton;
    QPushButton *cancelButton;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_7;
    QLineEdit *userNameEdit;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *firstNameEdit;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *lastNameEdit;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QLineEdit *passwordEdit;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_2;
    QLineEdit *emailEdit;
    QHBoxLayout *horizontalLayout_7;
    QLabel *interestsEdit;
    checkableComboBox *interestsBox;

    void setupUi(QDialog *createUser)
    {
        if (createUser->objectName().isEmpty())
            createUser->setObjectName("createUser");
        createUser->resize(310, 410);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(createUser->sizePolicy().hasHeightForWidth());
        createUser->setSizePolicy(sizePolicy);
        createUser->setMinimumSize(QSize(310, 410));
        createUser->setMaximumSize(QSize(310, 410));
        label = new QLabel(createUser);
        label->setObjectName("label");
        label->setGeometry(QRect(120, 20, 71, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(1);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        layoutWidget = new QWidget(createUser);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(20, 360, 271, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        submitButton = new QPushButton(layoutWidget);
        submitButton->setObjectName("submitButton");

        horizontalLayout->addWidget(submitButton);

        cancelButton = new QPushButton(layoutWidget);
        cancelButton->setObjectName("cancelButton");

        horizontalLayout->addWidget(cancelButton);

        layoutWidget1 = new QWidget(createUser);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(10, 50, 291, 291));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName("label_7");

        horizontalLayout_2->addWidget(label_7);

        userNameEdit = new QLineEdit(layoutWidget1);
        userNameEdit->setObjectName("userNameEdit");

        horizontalLayout_2->addWidget(userNameEdit);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName("label_3");

        horizontalLayout_3->addWidget(label_3);

        firstNameEdit = new QLineEdit(layoutWidget1);
        firstNameEdit->setObjectName("firstNameEdit");

        horizontalLayout_3->addWidget(firstNameEdit);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName("label_4");

        horizontalLayout_4->addWidget(label_4);

        lastNameEdit = new QLineEdit(layoutWidget1);
        lastNameEdit->setObjectName("lastNameEdit");

        horizontalLayout_4->addWidget(lastNameEdit);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName("label_5");

        horizontalLayout_5->addWidget(label_5);

        passwordEdit = new QLineEdit(layoutWidget1);
        passwordEdit->setObjectName("passwordEdit");

        horizontalLayout_5->addWidget(passwordEdit);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName("label_2");

        horizontalLayout_6->addWidget(label_2);

        emailEdit = new QLineEdit(layoutWidget1);
        emailEdit->setObjectName("emailEdit");

        horizontalLayout_6->addWidget(emailEdit);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        interestsEdit = new QLabel(layoutWidget1);
        interestsEdit->setObjectName("interestsEdit");

        horizontalLayout_7->addWidget(interestsEdit);

        interestsBox = new checkableComboBox(layoutWidget1);
        interestsBox->setObjectName("interestsBox");

        horizontalLayout_7->addWidget(interestsBox);


        verticalLayout->addLayout(horizontalLayout_7);


        retranslateUi(createUser);

        QMetaObject::connectSlotsByName(createUser);
    } // setupUi

    void retranslateUi(QDialog *createUser)
    {
        createUser->setWindowTitle(QCoreApplication::translate("createUser", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("createUser", "Welcome!", nullptr));
        submitButton->setText(QCoreApplication::translate("createUser", "Submit", nullptr));
        cancelButton->setText(QCoreApplication::translate("createUser", "Cancel", nullptr));
        label_7->setText(QCoreApplication::translate("createUser", "Username", nullptr));
        label_3->setText(QCoreApplication::translate("createUser", "First Name", nullptr));
        label_4->setText(QCoreApplication::translate("createUser", "Last Name", nullptr));
        lastNameEdit->setText(QString());
        label_5->setText(QCoreApplication::translate("createUser", "Password", nullptr));
        label_2->setText(QCoreApplication::translate("createUser", "Email", nullptr));
        interestsEdit->setText(QCoreApplication::translate("createUser", "Interests", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createUser: public Ui_createUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEUSER_H
