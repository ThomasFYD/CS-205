/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QFrame *line_5;
    QTextEdit *content;
    QPushButton *report;
    QLabel *timestamp;
    QLabel *label_11;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *profile;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QTextEdit *content_5;
    QTextEdit *content_6;
    QTextEdit *content_7;
    QLabel *label_13;
    QPushButton *pushButton_2;
    QFrame *line_9;
    QLabel *title;
    QPushButton *messages;
    QFrame *line_10;
    QPushButton *pushButton_3;
    QFrame *line_2;
    QFrame *line_11;
    QPushButton *feed;
    QFrame *line_3;
    QLabel *username;
    QPushButton *pushButton;
    QLabel *hashtags;
    QPushButton *pushButton_5;
    QFrame *line;
    QLabel *fullname;
    QLabel *label_12;
    QLabel *profilePicture;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(811, 754);
        line_5 = new QFrame(Dialog);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(850, 160, 20, 281));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        content = new QTextEdit(Dialog);
        content->setObjectName("content");
        content->setGeometry(QRect(280, 270, 551, 161));
        report = new QPushButton(Dialog);
        report->setObjectName("report");
        report->setGeometry(QRect(760, 170, 91, 31));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../database/pictures/1045119-200.png"), QSize(), QIcon::Normal, QIcon::Off);
        report->setIcon(icon);
        timestamp = new QLabel(Dialog);
        timestamp->setObjectName("timestamp");
        timestamp->setGeometry(QRect(770, 210, 71, 20));
        label_11 = new QLabel(Dialog);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(100, 90, 101, 101));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        verticalLayoutWidget = new QWidget(Dialog);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(241, 159, 631, 681));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        profile = new QPushButton(Dialog);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(800, 100, 100, 32));
        scrollArea = new QScrollArea(Dialog);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setGeometry(QRect(230, 150, 651, 1200));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy);
        scrollArea->setMinimumSize(QSize(500, 500));
        scrollArea->setMouseTracking(false);
        scrollArea->setStyleSheet(QString::fromUtf8("background-color:rgb(0, 0, 0)"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName("scrollAreaWidgetContents_2");
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 649, 1198));
        content_5 = new QTextEdit(scrollAreaWidgetContents_2);
        content_5->setObjectName("content_5");
        content_5->setGeometry(QRect(50, 300, 551, 161));
        content_6 = new QTextEdit(scrollAreaWidgetContents_2);
        content_6->setObjectName("content_6");
        content_6->setGeometry(QRect(50, 480, 551, 161));
        content_7 = new QTextEdit(scrollAreaWidgetContents_2);
        content_7->setObjectName("content_7");
        content_7->setGeometry(QRect(50, 580, 551, 161));
        scrollArea->setWidget(scrollAreaWidgetContents_2);
        label_13 = new QLabel(Dialog);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(100, 240, 111, 20));
        pushButton_2 = new QPushButton(Dialog);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(100, 350, 111, 29));
        line_9 = new QFrame(Dialog);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(230, 130, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        title = new QLabel(Dialog);
        title->setObjectName("title");
        title->setGeometry(QRect(280, 230, 441, 41));
        QFont font;
        font.setPointSize(16);
        title->setFont(font);
        messages = new QPushButton(Dialog);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(520, 100, 100, 32));
        line_10 = new QFrame(Dialog);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(230, 80, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        pushButton_3 = new QPushButton(Dialog);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(920, 690, 83, 29));
        line_2 = new QFrame(Dialog);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(250, 430, 611, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_11 = new QFrame(Dialog);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(910, 80, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        feed = new QPushButton(Dialog);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(240, 100, 100, 32));
        line_3 = new QFrame(Dialog);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(240, 160, 20, 281));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        username = new QLabel(Dialog);
        username->setObjectName("username");
        username->setGeometry(QRect(340, 190, 121, 20));
        pushButton = new QPushButton(Dialog);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(100, 300, 111, 29));
        hashtags = new QLabel(Dialog);
        hashtags->setObjectName("hashtags");
        hashtags->setGeometry(QRect(340, 210, 191, 20));
        pushButton_5 = new QPushButton(Dialog);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(980, 90, 31, 29));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../database/pictures/Ic_settings_48px.svg.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon1);
        pushButton_5->setCheckable(false);
        line = new QFrame(Dialog);
        line->setObjectName("line");
        line->setGeometry(QRect(250, 150, 611, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        fullname = new QLabel(Dialog);
        fullname->setObjectName("fullname");
        fullname->setGeometry(QRect(340, 170, 121, 20));
        label_12 = new QLabel(Dialog);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(100, 210, 91, 20));
        profilePicture = new QLabel(Dialog);
        profilePicture->setObjectName("profilePicture");
        profilePicture->setGeometry(QRect(260, 160, 71, 61));
        sizePolicy.setHeightForWidth(profilePicture->sizePolicy().hasHeightForWidth());
        profilePicture->setSizePolicy(sizePolicy);
        profilePicture->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        profilePicture->setScaledContents(true);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        content->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'.AppleSystemUIFont'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">I spent hours casting and reeling, determined to catch the biggest fish in the lake. My friends teased me, saying it was impossible, but I refused to give up. Finally, I felt a strong pull on my line and after a long battle, I pulled in a massive bass - easily the largest fish in the lake. My friends were amazed and I basked in the glo"
                        "ry of my accomplishment, knowing that I had truly become a master fisherman.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt; color:#00aaff;\">#bestdayofmylife #bass #record #winner</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt;\"><br /></p></body></html>", nullptr));
        report->setText(QCoreApplication::translate("Dialog", "Report", nullptr));
        timestamp->setText(QCoreApplication::translate("Dialog", "4/16/2023", nullptr));
        label_11->setText(QString());
        profile->setText(QCoreApplication::translate("Dialog", "Profile", nullptr));
        content_5->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'.AppleSystemUIFont'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">I spent hours casting and reeling, determined to catch the biggest fish in the lake. My friends teased me, saying it was impossible, but I refused to give up. Finally, I felt a strong pull on my line and after a long battle, I pulled in a massive bass - easily the largest fish in the lake. My friends were amazed and I basked in the glo"
                        "ry of my accomplishment, knowing that I had truly become a master fisherman.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt; color:#00aaff;\">#bestdayofmylife #bass #record #winner</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt;\"><br /></p></body></html>", nullptr));
        content_6->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'.AppleSystemUIFont'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">I spent hours casting and reeling, determined to catch the biggest fish in the lake. My friends teased me, saying it was impossible, but I refused to give up. Finally, I felt a strong pull on my line and after a long battle, I pulled in a massive bass - easily the largest fish in the lake. My friends were amazed and I basked in the glo"
                        "ry of my accomplishment, knowing that I had truly become a master fisherman.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt; color:#00aaff;\">#bestdayofmylife #bass #record #winner</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt;\"><br /></p></body></html>", nullptr));
        content_7->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'.AppleSystemUIFont'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt;\">I spent hours casting and reeling, determined to catch the biggest fish in the lake. My friends teased me, saying it was impossible, but I refused to give up. Finally, I felt a strong pull on my line and after a long battle, I pulled in a massive bass - easily the largest fish in the lake. My friends were amazed and I basked in the glo"
                        "ry of my accomplishment, knowing that I had truly become a master fisherman.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:9pt; color:#00aaff;\">#bestdayofmylife #bass #record #winner</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt;\"><br /></p></body></html>", nullptr));
        label_13->setText(QCoreApplication::translate("Dialog", "@humanefisher", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dialog", "Search Hashtags", nullptr));
        title->setText(QCoreApplication::translate("Dialog", "I Caught the Biggest Fish in the Lake!", nullptr));
        messages->setText(QCoreApplication::translate("Dialog", "Messages", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Dialog", "Log Out", nullptr));
        feed->setText(QCoreApplication::translate("Dialog", "Feed", nullptr));
        username->setText(QCoreApplication::translate("Dialog", "@fishmeister", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog", "Create Post", nullptr));
        hashtags->setText(QCoreApplication::translate("Dialog", "Interests: Stillwater, Fishing", nullptr));
        pushButton_5->setText(QString());
        fullname->setText(QCoreApplication::translate("Dialog", "John Doe", nullptr));
        label_12->setText(QCoreApplication::translate("Dialog", "Salty Steve", nullptr));
        profilePicture->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
