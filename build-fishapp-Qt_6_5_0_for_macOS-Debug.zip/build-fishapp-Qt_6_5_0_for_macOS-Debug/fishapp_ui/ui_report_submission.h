/********************************************************************************
** Form generated from reading UI file 'report_submission.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REPORT_SUBMISSION_H
#define UI_REPORT_SUBMISSION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_report_submission
{
public:
    QTextEdit *textEdit;
    QLabel *label;
    QPushButton *submitButtom;
    QPushButton *cancelButton;

    void setupUi(QDialog *report_submission)
    {
        if (report_submission->objectName().isEmpty())
            report_submission->setObjectName("report_submission");
        report_submission->resize(584, 390);
        textEdit = new QTextEdit(report_submission);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(40, 90, 511, 231));
        label = new QLabel(report_submission);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 40, 181, 20));
        submitButtom = new QPushButton(report_submission);
        submitButtom->setObjectName("submitButtom");
        submitButtom->setGeometry(QRect(350, 340, 83, 29));
        cancelButton = new QPushButton(report_submission);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setGeometry(QRect(470, 340, 83, 29));

        retranslateUi(report_submission);

        QMetaObject::connectSlotsByName(report_submission);
    } // setupUi

    void retranslateUi(QDialog *report_submission)
    {
        report_submission->setWindowTitle(QCoreApplication::translate("report_submission", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("report_submission", "Explain Report Reasoning:", nullptr));
        submitButtom->setText(QCoreApplication::translate("report_submission", "Submit", nullptr));
        cancelButton->setText(QCoreApplication::translate("report_submission", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class report_submission: public Ui_report_submission {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REPORT_SUBMISSION_H
