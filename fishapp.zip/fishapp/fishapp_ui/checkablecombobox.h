#ifndef CHECKABLECOMBOBOX_H
#define CHECKABLECOMBOBOX_H

#include <QComboBox>
#include <QMouseEvent>

class checkableComboBox : public QComboBox
{
    Q_OBJECT

public:
    explicit checkableComboBox(QWidget *parent = nullptr);

protected:
    void hidePopup() override;
};

#endif // CHECKABLECOMBOBOX_H
