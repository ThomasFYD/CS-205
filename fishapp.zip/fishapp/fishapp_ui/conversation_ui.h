#ifndef CONVERSATION_UI_H
#define CONVERSATION_UI_H

#include <QDialog>
#include "../feed/user_feed.h"
#include "../authentication_engine/auth_manager.h"
#include "../authentication_engine/user.h"
#include "../messaging/conversation.h"
#include "../messaging/one_conversation.h"
#include "main_feed.h"
#include "qmainwindow.h"
#include "ui_conversation.h"

namespace Ui {
class conversation_ui;
}

class conversation_ui : public QDialog
{
    Q_OBJECT

public:
    explicit conversation_ui(QMainWindow* mainWindow, QWidget *parent, auth_manager& userAuthenticaitonr);
    ~conversation_ui();

private slots:
    void on_messages_clicked();
    void on_profile_clicked();
    void on_feed_clicked();
    void on_next_clicked();
    void on_previous_clicked();
    void on_chat_clicked();
    void on_deleteButton_clicked();
    void on_setting_clicked();
    void load_conversations();

private:
    Ui::conversation_ui *ui;
    int position;
    user* currentUser;
    user_feed myFeed;
    conversation myConvo;
    std::vector<one_conversation> myConversations;
    QMainWindow* myWindow;
    auth_manager& myManager;
    int userId2;
};

#endif // CONVERSATION_UI_H
