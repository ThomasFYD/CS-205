#include "moderator_feed.h"
#include "ui_moderator_feed.h"

// In moderator_feed.cpp, in the moderator_feed constructor
moderator_feed::moderator_feed(QMainWindow* mainWindow, moderation_manager &modAuthenticaiton, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::moderator_feed),
    currentModerator(modAuthenticaiton.getCurrentModerator()),
    myModManager(modAuthenticaiton),
    mainWindow(mainWindow)
{
    ui->setupUi(this);

    allReports = myModManager.all_reports();
    if (allReports.size() < 1) {
        position = -1;
    } else {
        position = 0;
    }
    this->load_report();

    ui->modFullLabel->setText(currentModerator->getFirstName() + " " + currentModerator->getFirstName());
    ui->modIDLabel->setText("Admin #" + QString::number(currentModerator->getModeratorId()));
    ui->modUsernameLabel->setText("@" + currentModerator->getUsername());
}


moderator_feed::~moderator_feed()
{
    delete ui;
}

void moderator_feed::load_report() {
    if (position >= 0 && position < allReports.size()) {

        std::vector<std::string> reportData = allReports.at(position);
        ui->reportIDLabel->setText("Report ID : " + QString::fromStdString(reportData[0]));
        ui->reporterIDLabel->setText("Reporter #" + QString::fromStdString(reportData[1]));
        ui->postLabel->setText(QString::fromStdString(reportData[2]));
        ui->reasonLabel->setText("Reason: " + QString::fromStdString(reportData[3]));
        ui->timeLabel->setText(QString::fromStdString(reportData[4]));
        ui->userIDLabel->setText(QString::fromStdString(reportData[5]));
        ui->post_title->setText(QString::fromStdString(reportData[6]));
    } else {
        // Handle cases when there are no reports or position is out of bounds
        QMessageBox::information(this, "No Reports", "There are no reports to review.");
    }
}

void moderator_feed::on_previousButton_clicked()
{
    if (position > 0) {
        position = position - 1;
        this->load_report();
    }
}


void moderator_feed::on_nextButton_clicked()
{
    if (position < allReports.size() - 1) {
        position = position + 1;
        this->load_report();
    }
}


void moderator_feed::on_pushButton_8_clicked()
{
    myModManager.logout();
    this->close();
    mainWindow->show();
}


void moderator_feed::on_banUserButton_clicked()
{
    if (allReports.size() == 0){
        QMessageBox::warning(this, "Ban User", "No more reports");
        return;
    }

    int user_id = ui->userIDLabel->text().toInt();
    QString ban_reason = ui->decisionEdit->toPlainText();

    if (myModManager.getCurrentModerator()->removeUser(user_id, ban_reason)) {
        QMessageBox::information(this, "Ban User", "The user has been banned successfully.");
        allReports = myModManager.all_reports();
    } else {
        QMessageBox::warning(this, "Ban User", "Failed to ban the user.");
        return;
    }

    allReports = myModManager.all_reports();

    // Check if there are more reports available
    if (position < allReports.size()) {
        // Load next report
        load_report();
    } else {
        // No more reports available, display a message or close the moderator_feed window
        QMessageBox::information(this, "No More Reports", "There are no more reports to review.");

        position = -1;

        // this->close();
    }
}


void moderator_feed::on_removePostButton_clicked()
{

    if (allReports.size() == 0){
        QMessageBox::warning(this, "Remove Post", "No more reports");
        return;
    }

    if (myModManager.getCurrentModerator()->removePost(ui->postLabel->text().toInt(), ui->decisionEdit->toPlainText())) {
        QMessageBox::information(this, "Ban User", "The user has been banned successfully.");
        allReports = myModManager.all_reports();
    } else {
        QMessageBox::warning(this, "Ban User", "Failed to ban the user.");
        return;
    }


    // Update the reports
    updateFeed();

    // Check if there are more reports available
    if (position < allReports.size() - 1) {
        // Increment position to load next report
        position++;
        // Load next report
        load_report();
    } else {
        // No more reports available, display a message or close the moderator_feed window
        QMessageBox::information(this, "No More Reports", "There are no more reports to review.");
        position = -1;
        // this->close();
    }
}


void moderator_feed::updateFeed() {
    allReports = myModManager.all_reports();
    if (allReports.size() < 1) {
        position = -1;
        ui->reportIDLabel->setText("Report ID : ");
        ui->reporterIDLabel->setText("Reporter #");
        ui->postLabel->setText("NO REPORTS");
        ui->reasonLabel->setText("");
        ui->timeLabel->setText("");
        ui->userIDLabel->setText("User #");
        ui->post_title->setText("NO REPORTS");
    } else {
        position = 0;
        this->load_report();
    }
}

