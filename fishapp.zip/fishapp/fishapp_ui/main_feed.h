#ifndef MAIN_FEED_H
#define MAIN_FEED_H

#include <QDialog>
#include "../post/one_post.h"
#include "../feed/user_feed.h"
#include "../authentication_engine/auth_manager.h"
#include "../authentication_engine/user.h"
#include "qmainwindow.h"


namespace Ui {
class main_feed;
}

class main_feed : public QDialog
{
    Q_OBJECT

public:
   explicit main_feed(QMainWindow* mainWindow, auth_manager &userAuthenticaiton, QWidget *parent = nullptr);
    ~main_feed();

private slots:

    void on_feed_clicked();

    void on_messages_clicked();

    void on_profile_clicked();

    void load_post();

    void on_log_out_clicked();

    void on_create_post_clicked();

    void on_search_hashtag_clicked();

    void on_previous_post_clicked();

    void on_next_post_clicked();

    void on_report_clicked();

    void updateFeed();

private:
    Ui::main_feed *ui;
    std::vector<one_post> myPosts;
    user* currentUser;
    user_feed myFeed;
    int position;
    auth_manager& myManager;
    QMainWindow* mainWindow;
};

#endif // MAIN_FEED_H
