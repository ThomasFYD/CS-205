CREATE TABLE Users (
  user_id INTEGER NOT NULL UNIQUE,
  username TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  date_of_registration TEXT NOT NULL,
  shadowbanned BOOLEAN NOT NULL DEFAULT FALSE,
  PRIMARY KEY (user_id)
);

CREATE TABLE Moderators (
  moderator_id INTEGER NOT NULL UNIQUE,
  user_id INTEGER NOT NULL UNIQUE,
  PRIMARY KEY (moderator_id),
  FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE UserInterests (
  user_id INTEGER NOT NULL,
  hashtag_id INTEGER NOT NULL,
  PRIMARY KEY (user_id, hashtag_id),
  FOREIGN KEY (user_id) REFERENCES Users(user_id),
  FOREIGN KEY (hashtag_id) REFERENCES Hashtags(hashtag_id)
);

CREATE TABLE Authentication (
  user_id INTEGER NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_reset_token TEXT,
  last_login_timestamp TEXT,
  PRIMARY KEY (user_id),
  FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE Conversations (
  conversation_id INTEGER NOT NULL UNIQUE,
  user1_id INTEGER NOT NULL,
  user2_id INTEGER NOT NULL,
  PRIMARY KEY (conversation_id),
  FOREIGN KEY (user1_id) REFERENCES Users(user_id),
  FOREIGN KEY (user2_id) REFERENCES Users(user_id)
);

CREATE TABLE Messages (
  message_id INTEGER NOT NULL UNIQUE,
  conversation_id INTEGER NOT NULL,
  sender_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  PRIMARY KEY (message_id),
  FOREIGN KEY (conversation_id) REFERENCES Conversations(conversation_id),
  FOREIGN KEY (sender_id) REFERENCES Users(user_id)
);

CREATE TABLE Attachments (
  attachment_id INTEGER NOT NULL UNIQUE,
  message_id INTEGER NOT NULL,
  attachment_url TEXT NOT NULL,
  PRIMARY KEY (attachment_id),
  FOREIGN KEY (message_id) REFERENCES Messages(message_id)
);

CREATE TABLE Notifications (
  notification_id INTEGER NOT NULL UNIQUE,
  notification_type TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  related_message_id INTEGER NOT NULL,
  timestamp TEXT NOT NULL,
  PRIMARY KEY (notification_id),
  FOREIGN KEY (user_id) REFERENCES Users(user_id),
  FOREIGN KEY (related_message_id) REFERENCES Messages(message_id)
);

CREATE TABLE Posts (
  post_id INTEGER NOT NULL UNIQUE,
  author_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  PRIMARY KEY (post_id),
  FOREIGN KEY (author_id) REFERENCES Users(user_id)
);

CREATE TABLE Hashtags (
  hashtag_id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  PRIMARY KEY (hashtag_id)
);

CREATE TABLE PostHashtags (
  post_id INTEGER NOT NULL,
  hashtag_id INTEGER NOT NULL,
  PRIMARY KEY (post_id, hashtag_id),
  FOREIGN KEY (post_id) REFERENCES Posts(post_id),
  FOREIGN KEY (hashtag_id) REFERENCES Hashtags(hashtag_id)
);

CREATE TABLE PostReports (
  report_id INTEGER NOT NULL UNIQUE,
  post_id INTEGER NOT NULL,
  reporter_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  PRIMARY KEY (report_id),
  FOREIGN KEY (post_id) REFERENCES Posts(post_id),
  FOREIGN KEY (reporter_id) REFERENCES Users(user_id)
);

CREATE TABLE RemovedPosts (
  removed_post_id INTEGER NOT NULL UNIQUE,
  post_id INTEGER NOT NULL,
  moderator_id INTEGER NOT NULL,
  removal_reason TEXT NOT NULL,
  removal_timestamp TEXT NOT NULL,
  PRIMARY KEY (removed_post_id),
  FOREIGN KEY (post_id) REFERENCES Posts(post_id),
  FOREIGN KEY (moderator_id) REFERENCES Moderators(moderator_id)
);


CREATE TABLE UserJail (
  user_id INTEGER NOT NULL UNIQUE,
  jail_start_timestamp TEXT NOT NULL,
  jail_duration INTEGER NOT NULL,
  jail_reason TEXT NOT NULL,
  PRIMARY KEY (user_id),
  FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE RemovedUsers (
  removed_user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  moderator_id INTEGER NOT NULL,
  removal_reason TEXT NOT NULL,
  removal_timestamp TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES Users(user_id),
  FOREIGN KEY (moderator_id) REFERENCES Moderators(moderator_id)
);



.separator ","
.mode csv
.import "00_build_db/interests.csv" Hashtags
.import "00_build_db/users.csv" Users
.import "00_build_db/moderators.csv" Moderators
.import "00_build_db/authentication.csv" Authentication

