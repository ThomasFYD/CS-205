#include "messaging.h"
#include "main_feed.h"

messaging::messaging(QMainWindow* mainWindow, QWidget *parent, auth_manager& userAuthentication,int userId_2) :
    QDialog(parent),
    ui(new Ui::messaging),
    myWindow(mainWindow),
    myAuthentication(userAuthentication),
    myManager(userAuthentication),
    convo(userAuthentication)
{
    ui->setupUi(this);
    userId2 = userId_2;
}

messaging::~messaging() {
    delete ui;
}

void messaging::on_send_clicked() {
    const QString str = ui->lineEdit->text();

    convo.send_message(userId2,str.toStdString());
}

void messaging::on_cancel_clicked() {
    main_feed* mainFeed = new main_feed(myWindow, myManager, this);
    mainFeed->show();
    this->hide();
}

//void messaging::on_report_clicked() {
//    report_submission* reportsub = new report_submission(myWindow, this, myManager);
//    reportsub->show();
//    this->hide();
//}

void messaging::display() {

}
