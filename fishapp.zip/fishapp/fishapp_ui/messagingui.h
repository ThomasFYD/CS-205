//#ifndef MESSAGINGUI_H
//#define MESSAGINGUI_H

//#include <QWidget>
//#include <QTextEdit>
//#include <QLineEdit>
//#include <QPushButton>
//#include <QVBoxLayout>
//#include <QHBoxLayout>

//class MessagingUI : public QWidget {
//    Q_OBJECT
//public:
//    explicit MessagingUI(QWidget *parent = nullptr);
//    ~MessagingUI();

//private:
//    QTextEdit *messageDisplay;
//    QLineEdit *messageInput;
//    QPushButton *sendButton;
//    QVBoxLayout *mainLayout;
//    QHBoxLayout *inputLayout;
//};

//#endif // MESSAGINGUI_H
