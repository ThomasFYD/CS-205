#include <iostream>
#include "gtest/gtest.h"
#include "../authentication_engine/user.h"
#include "../authentication_engine/auth_manager.h"
#include "../post/one_post.h"
#include "../post/upload.h"
#include "../feed/user_feed.h"

class MessagingTest : public ::testing::Test {
protected:

    db_access myDb;
    auth_manager authManager;
    user_feed myFeed;

    MessagingTest(): authManager(myDb), myFeed(authManager) {
        //adding users for the tests
//        authManager.createUser("testuser1", "first", "last", "email1@example.com", "2023-04-04", "testpassword", 1200);
//        authManager.createUser("testuser2", "first", "last", "email2@example.com", "2023-04-04", "testpassword", 1201);
//        authManager.createUser("testuser3", "first", "last", "email3@example.com", "2023-04-04", "testpassword", 1202);
//        authManager.createUser("testuser4", "first", "last", "email4@example.com", "2023-04-04", "testpassword", 1203);

    }
    virtual ~MessagingTest() {
//        authManager.removeUser(1200);
//        authManager.removeUser(1201);
//        authManager.removeUser(1202);
//        authManager.removeUser(1203);
    }

    virtual void SetUp() {

    }
    virtual void TearDown() {

    }
};

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
