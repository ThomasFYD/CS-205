#ifndef LOGIN_USER_H
#define LOGIN_USER_H


#include <QDialog>
#include "../authentication_engine/auth_manager.h"
#include "qmainwindow.h"
#include <QMessageBox>
#include <QRegularExpression>

namespace Ui {
class login_user;
}

class login_user : public QDialog
{
    Q_OBJECT

public:
    explicit login_user(auth_manager& manager, QMainWindow* mainWindow, QWidget *parent = nullptr);
    ~login_user();

private slots:
    void on_cancelButton_clicked();
    void on_submitButton_clicked();

private:
    Ui::login_user *ui;
    auth_manager& myManager;
    QMainWindow* mainWindow;
};

#endif // LOGIN_USER_H
