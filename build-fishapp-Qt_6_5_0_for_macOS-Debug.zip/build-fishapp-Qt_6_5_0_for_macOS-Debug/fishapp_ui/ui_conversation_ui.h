/********************************************************************************
** Form generated from reading UI file 'conversation_ui.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERSATION_UI_H
#define UI_CONVERSATION_UI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_conversation_ui
{
public:
    QLabel *label_2;
    QPushButton *previous;
    QPushButton *deleteButton;
    QLabel *label_11;
    QPushButton *next;
    QFrame *line_9;
    QLabel *userName;
    QFrame *line_12;
    QLabel *label_3;
    QLabel *fullName;
    QPushButton *profile;
    QPushButton *messages;
    QPushButton *feed;
    QPushButton *chat;

    void setupUi(QDialog *conversation_ui)
    {
        if (conversation_ui->objectName().isEmpty())
            conversation_ui->setObjectName("conversation_ui");
        conversation_ui->resize(830, 625);
        label_2 = new QLabel(conversation_ui);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(400, 160, 121, 20));
        previous = new QPushButton(conversation_ui);
        previous->setObjectName("previous");
        previous->setGeometry(QRect(200, 200, 61, 32));
        deleteButton = new QPushButton(conversation_ui);
        deleteButton->setObjectName("deleteButton");
        deleteButton->setGeometry(QRect(480, 250, 83, 29));
        label_11 = new QLabel(conversation_ui);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(0, 90, 101, 101));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        next = new QPushButton(conversation_ui);
        next->setObjectName("next");
        next->setGeometry(QRect(640, 200, 61, 32));
        line_9 = new QFrame(conversation_ui);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(120, 80, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        userName = new QLabel(conversation_ui);
        userName->setObjectName("userName");
        userName->setGeometry(QRect(0, 250, 111, 20));
        line_12 = new QFrame(conversation_ui);
        line_12->setObjectName("line_12");
        line_12->setGeometry(QRect(90, 550, 681, 31));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        label_3 = new QLabel(conversation_ui);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(400, 200, 121, 20));
        fullName = new QLabel(conversation_ui);
        fullName->setObjectName("fullName");
        fullName->setGeometry(QRect(0, 210, 91, 20));
        profile = new QPushButton(conversation_ui);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(690, 50, 100, 32));
        messages = new QPushButton(conversation_ui);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(410, 50, 100, 32));
        feed = new QPushButton(conversation_ui);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(130, 50, 100, 32));
        chat = new QPushButton(conversation_ui);
        chat->setObjectName("chat");
        chat->setGeometry(QRect(310, 250, 83, 29));

        retranslateUi(conversation_ui);

        QMetaObject::connectSlotsByName(conversation_ui);
    } // setupUi

    void retranslateUi(QDialog *conversation_ui)
    {
        conversation_ui->setWindowTitle(QCoreApplication::translate("conversation_ui", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("conversation_ui", "John Doe", nullptr));
        previous->setText(QCoreApplication::translate("conversation_ui", "<", nullptr));
        deleteButton->setText(QCoreApplication::translate("conversation_ui", "Delete", nullptr));
        label_11->setText(QString());
        next->setText(QCoreApplication::translate("conversation_ui", ">", nullptr));
        userName->setText(QCoreApplication::translate("conversation_ui", "@humanefisher", nullptr));
        label_3->setText(QCoreApplication::translate("conversation_ui", "@fishmeister", nullptr));
        fullName->setText(QCoreApplication::translate("conversation_ui", "Salty Steve", nullptr));
        profile->setText(QCoreApplication::translate("conversation_ui", "Profile", nullptr));
        messages->setText(QCoreApplication::translate("conversation_ui", "Messages", nullptr));
        feed->setText(QCoreApplication::translate("conversation_ui", "Feed", nullptr));
        chat->setText(QCoreApplication::translate("conversation_ui", "Chat", nullptr));
    } // retranslateUi

};

namespace Ui {
    class conversation_ui: public Ui_conversation_ui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERSATION_UI_H
