#include "user_profile.h"
#include "ui_user_profile.h"
#include "main_feed.h"
#include "mainwindow.h"



user_profile::user_profile(QMainWindow* mainWindow, QWidget *parent,  auth_manager& userAuthenticaiton) :
    QDialog(parent),
    ui(new Ui::user_profile),
    currentUser(userAuthenticaiton.getCurrentUser()),
    myManager(userAuthenticaiton),
    myUpload(myManager),
    mainWindow(mainWindow)
{
    ui->setupUi(this);
    ui->user_username->setText("@" + currentUser->getUsername());
    ui->user_fullname->setText(currentUser->getFirstName() + " " + currentUser->getLastName());
    //STILL NEED TO DISPLAY INTERESTS
    myPosts = myUpload.findPosts();
    if(myPosts.size()<1){
        position = -1;
    }
    else{
        position = 0;
        this->load_post();
    }
}

user_profile::~user_profile()
{
    delete ui;
}

void user_profile::on_feed_clicked()
{
    main_feed* userFeed = new main_feed(mainWindow, myManager);
    userFeed->show();
    this->close();
}


void user_profile::on_messages_clicked()
{
    //takes you to messages
}


void user_profile::on_profile_clicked()
{
    //reloads user profile
    user_profile* userProfile = new user_profile(mainWindow, this, myManager);
    userProfile->show();
    this->hide();
}


void user_profile::on_settings_clicked()
{
    //takes you to settings
}


void user_profile::on_log_out_clicked()
{
    myManager.logout();
    this->close();
    mainWindow->show();
}


void user_profile::on_previous_post_clicked()
{
    if(position > 0){
        position = position - 1;
        this->load_post();
    }
}


void user_profile::on_next_post_clicked()
{
    if(position < myPosts.size() -1){

        position = position + 1;

    }
    this->load_post();
}


void user_profile::on_delete_post_clicked()
{
    if(position > -1){
        myUpload.delete_post(myPosts.at(position).return_postId());
        myPosts = myUpload.findPosts();
        if(myPosts.size() == 0){
            position = -1;
        }
        else{
            position = 0;
        }
        this->load_post();
    }
}

void user_profile::load_post(){
    if(position!=-1){
        std::vector<std::string> info = myUpload.findInformation(myPosts.at(position).return_postId());
        std::string hashtags;
        for(int i = 3; i < info.size(); i++){
            hashtags = hashtags + info.at(i) + " ";
        }
        ui->post_fullname->setText(QString::fromStdString(info.at(1) + " " + info.at(2)));
        ui->post_content->setText(myPosts.at(position).return_content());
        ui->post_hashtags->setText(QString::fromStdString(hashtags));
        ui->post_username->setText(QString::fromStdString(info.at(0)));
        ui->post_timestamp->setText(myPosts.at(position).return_timestamp());
        ui->post_title->setText(myPosts.at(position).return_title());
    }
}

