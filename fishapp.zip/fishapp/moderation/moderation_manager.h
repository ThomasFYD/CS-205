#ifndef MODERATION_MANAGER_H
#define MODERATION_MANAGER_H

#include <iostream>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include "../db/db_access.h"
#include "moderator.h"

class moderation_manager
{
public:
    moderation_manager(db_access& dbAccess);

    bool assignModerator(int user_id);

    bool checkModerator(int user_id);

    bool checkModerator(QString username);

    bool authenticateModerator(QString username, QString password);

    void logout();

    bool updateModerator(QString username);

    std::vector<std::vector<std::string>> all_reports();

    moderator* getCurrentModerator();

//    ~moderation_manager() {
//        delete currentModerator;
//    }
private:
    db_access& m_dbAccess;
    moderator* currentModerator;
};

#endif // MODERATION_MANAGER_H

