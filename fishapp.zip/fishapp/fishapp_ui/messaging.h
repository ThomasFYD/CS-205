#ifndef MESSAGING_H
#define MESSAGING_H

#include <QDialog>
#include "ui_messaging.h"
#include "../authentication_engine/auth_manager.h"
#include "../authentication_engine/user.h"
#include "../messaging/conversation.h"
#include "../messaging/one_conversation.h"
#include "qmainwindow.h"
#include "checkablecombobox.h"
#include "conversation_ui.h"
//#include "../feed/feed"
//#include "../feed/Makefile"
#include "../feed/user_feed.h"

namespace Ui {
class messaging;
}

class messaging : public QDialog
{
    Q_OBJECT

public:
    explicit messaging(QMainWindow* mainWindow, QWidget *parent, auth_manager& userAuthentication,int userId2);
    ~messaging();

private slots:
    void on_send_clicked();
    void on_cancel_clicked();
    void display();

private:
    Ui::messaging *ui;
    auth_manager& myAuthentication;
    conversation convo;
    QMainWindow* myWindow;
    auth_manager& myManager;
    int userId2;
};

#endif // MESSAGING_H
