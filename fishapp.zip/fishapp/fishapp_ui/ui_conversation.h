//#ifndef UI_CONVERSATION_H
//#define UI_CONVERSATION_H

//#include <QDialog>
//#include "../feed/user_feed.h"
//#include "../authentication_engine/auth_manager.h"
//#include "../authentication_engine/user.h"
//#include "../messaging/conversation.h"
//#include "../messaging/one_conversation.h"
//#include "main_feed.h"
//#include "qmainwindow.h"
//#include "ui_conversation.h"

//namespace Ui {
//class ui_conversation;
//}

//class ui_conversation : public QDialog
//{
//    Q_OBJECT

//public:
//    explicit ui_conversation(QMainWindow* mainWindow, QWidget *parent, auth_manager& userAuthenticaiton);
//    ~ui_conversation();

//private slots:
//    void on_messages_clicked();
//    void on_profile_clicked();
//    void on_feed_clicked();
//    void on_next_clicked();
//    void on_previous_clicked();
//    void on_chat_clicked();
//    void on_deleteButton_clicked();
//    void on_setting_clicked();
//    void load_conversations();


//private:
//    Ui::ui_conversation *ui;
//    int position;
//    user* currentUser;
//    user_feed myFeed;
//    conversation myConvo;
//    std::vector<one_conversation> myConversations;
//    QMainWindow* myWindow;
//    auth_manager& myManager;
//    int userId2;
//};

//#endif // UI_CONVERSATION_H
