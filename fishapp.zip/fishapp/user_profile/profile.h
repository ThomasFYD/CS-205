#ifndef PROFILE_H
#define PROFILE_H


class profile
{
public:
    profile();
};

#endif // PROFILE_H
