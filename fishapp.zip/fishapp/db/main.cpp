#include "db_access.h"
#include <iostream>

using namespace std;

int main()
{
    db_access();
    return 0;
}
