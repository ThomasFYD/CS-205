/****************************************************************************
** Meta object code from reading C++ file 'visiting_user_profile.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../fishapp/fishapp_ui/visiting_user_profile.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'visiting_user_profile.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS = QtMocHelpers::stringData(
    "visiting_user_profile",
    "on_report_post_clicked",
    "",
    "on_previous_post_clicked",
    "on_next_post_clicked",
    "on_log_out_clicked",
    "on_conversation_clicked",
    "on_messages_clicked",
    "on_feed_clicked",
    "on_profile_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS_t {
    uint offsetsAndSizes[20];
    char stringdata0[22];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[25];
    char stringdata4[21];
    char stringdata5[19];
    char stringdata6[24];
    char stringdata7[20];
    char stringdata8[16];
    char stringdata9[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS_t qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS = {
    {
        QT_MOC_LITERAL(0, 21),  // "visiting_user_profile"
        QT_MOC_LITERAL(22, 22),  // "on_report_post_clicked"
        QT_MOC_LITERAL(45, 0),  // ""
        QT_MOC_LITERAL(46, 24),  // "on_previous_post_clicked"
        QT_MOC_LITERAL(71, 20),  // "on_next_post_clicked"
        QT_MOC_LITERAL(92, 18),  // "on_log_out_clicked"
        QT_MOC_LITERAL(111, 23),  // "on_conversation_clicked"
        QT_MOC_LITERAL(135, 19),  // "on_messages_clicked"
        QT_MOC_LITERAL(155, 15),  // "on_feed_clicked"
        QT_MOC_LITERAL(171, 18)   // "on_profile_clicked"
    },
    "visiting_user_profile",
    "on_report_post_clicked",
    "",
    "on_previous_post_clicked",
    "on_next_post_clicked",
    "on_log_out_clicked",
    "on_conversation_clicked",
    "on_messages_clicked",
    "on_feed_clicked",
    "on_profile_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSvisiting_user_profileENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   62,    2, 0x08,    1 /* Private */,
       3,    0,   63,    2, 0x08,    2 /* Private */,
       4,    0,   64,    2, 0x08,    3 /* Private */,
       5,    0,   65,    2, 0x08,    4 /* Private */,
       6,    0,   66,    2, 0x08,    5 /* Private */,
       7,    0,   67,    2, 0x08,    6 /* Private */,
       8,    0,   68,    2, 0x08,    7 /* Private */,
       9,    0,   69,    2, 0x08,    8 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject visiting_user_profile::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSvisiting_user_profileENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<visiting_user_profile, std::true_type>,
        // method 'on_report_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_previous_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_next_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_log_out_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_conversation_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_messages_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_feed_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_profile_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void visiting_user_profile::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<visiting_user_profile *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_report_post_clicked(); break;
        case 1: _t->on_previous_post_clicked(); break;
        case 2: _t->on_next_post_clicked(); break;
        case 3: _t->on_log_out_clicked(); break;
        case 4: _t->on_conversation_clicked(); break;
        case 5: _t->on_messages_clicked(); break;
        case 6: _t->on_feed_clicked(); break;
        case 7: _t->on_profile_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *visiting_user_profile::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *visiting_user_profile::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSvisiting_user_profileENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int visiting_user_profile::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP
