/********************************************************************************
** Form generated from reading UI file 'messaging.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESSAGING_H
#define UI_MESSAGING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>

QT_BEGIN_NAMESPACE

class Ui_messaging
{
public:
    QPushButton *cancel;
    QPushButton *send;
    QLineEdit *lineEdit;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *vuser_name;
    QLabel *label;
    QLabel *user_name;
    QLabel *user_msg;
    QLabel *vuser_msg;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QLabel *vuser_pic;
    QLabel *vuser_fname;
    QLabel *vuser_name2;
    QLabel *user_date;
    QLabel *vuser_date;
    QScrollBar *verticalScrollBar;

    void setupUi(QDialog *messaging)
    {
        if (messaging->objectName().isEmpty())
            messaging->setObjectName("messaging");
        messaging->resize(884, 871);
        cancel = new QPushButton(messaging);
        cancel->setObjectName("cancel");
        cancel->setGeometry(QRect(260, 550, 83, 29));
        send = new QPushButton(messaging);
        send->setObjectName("send");
        send->setGeometry(QRect(150, 550, 83, 29));
        lineEdit = new QLineEdit(messaging);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(140, 440, 591, 101));
        label_11 = new QLabel(messaging);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(650, 250, 71, 71));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        label_12 = new QLabel(messaging);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(160, 40, 91, 20));
        vuser_name = new QLabel(messaging);
        vuser_name->setObjectName("vuser_name");
        vuser_name->setGeometry(QRect(240, 360, 111, 20));
        label = new QLabel(messaging);
        label->setObjectName("label");
        label->setGeometry(QRect(160, 360, 71, 61));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        label->setScaledContents(true);
        user_name = new QLabel(messaging);
        user_name->setObjectName("user_name");
        user_name->setGeometry(QRect(550, 250, 121, 20));
        user_msg = new QLabel(messaging);
        user_msg->setObjectName("user_msg");
        user_msg->setGeometry(QRect(290, 280, 361, 21));
        vuser_msg = new QLabel(messaging);
        vuser_msg->setObjectName("vuser_msg");
        vuser_msg->setGeometry(QRect(240, 390, 221, 20));
        line = new QFrame(messaging);
        line->setObjectName("line");
        line->setGeometry(QRect(130, 100, 20, 341));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(messaging);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(140, 90, 591, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(messaging);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(723, 100, 20, 341));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        vuser_pic = new QLabel(messaging);
        vuser_pic->setObjectName("vuser_pic");
        vuser_pic->setGeometry(QRect(10, 100, 101, 101));
        vuser_pic->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        vuser_pic->setScaledContents(true);
        vuser_fname = new QLabel(messaging);
        vuser_fname->setObjectName("vuser_fname");
        vuser_fname->setGeometry(QRect(20, 230, 91, 20));
        vuser_name2 = new QLabel(messaging);
        vuser_name2->setObjectName("vuser_name2");
        vuser_name2->setGeometry(QRect(20, 260, 111, 20));
        user_date = new QLabel(messaging);
        user_date->setObjectName("user_date");
        user_date->setGeometry(QRect(570, 300, 63, 20));
        vuser_date = new QLabel(messaging);
        vuser_date->setObjectName("vuser_date");
        vuser_date->setGeometry(QRect(240, 420, 63, 20));
        verticalScrollBar = new QScrollBar(messaging);
        verticalScrollBar->setObjectName("verticalScrollBar");
        verticalScrollBar->setGeometry(QRect(140, 100, 16, 341));
        verticalScrollBar->setOrientation(Qt::Vertical);

        retranslateUi(messaging);

        QMetaObject::connectSlotsByName(messaging);
    } // setupUi

    void retranslateUi(QDialog *messaging)
    {
        messaging->setWindowTitle(QCoreApplication::translate("messaging", "Dialog", nullptr));
        cancel->setText(QCoreApplication::translate("messaging", "Cancel", nullptr));
        send->setText(QCoreApplication::translate("messaging", "Send", nullptr));
        label_11->setText(QString());
        label_12->setText(QString());
        vuser_name->setText(QCoreApplication::translate("messaging", "@humanefisher", nullptr));
        label->setText(QString());
        user_name->setText(QCoreApplication::translate("messaging", "@fishmeister", nullptr));
        user_msg->setText(QCoreApplication::translate("messaging", "Hey! I read your story and thought it was interesting!", nullptr));
        vuser_msg->setText(QCoreApplication::translate("messaging", "Thank you! Wanna see pictures?", nullptr));
        vuser_pic->setText(QString());
        vuser_fname->setText(QCoreApplication::translate("messaging", "Salty Steve", nullptr));
        vuser_name2->setText(QCoreApplication::translate("messaging", "@humanefisher", nullptr));
        user_date->setText(QCoreApplication::translate("messaging", "4/16/23", nullptr));
        vuser_date->setText(QCoreApplication::translate("messaging", "4/16/23", nullptr));
    } // retranslateUi

};

namespace Ui {
    class messaging: public Ui_messaging {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESSAGING_H
