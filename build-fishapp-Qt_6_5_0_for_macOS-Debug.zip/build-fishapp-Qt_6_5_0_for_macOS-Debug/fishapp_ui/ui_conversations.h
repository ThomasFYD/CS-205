/********************************************************************************
** Form generated from reading UI file 'conversations.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERSATIONS_H
#define UI_CONVERSATIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *messages;
    QFrame *line_9;
    QPushButton *profile;
    QFrame *line_12;
    QPushButton *feed;
    QLabel *label_3;
    QLabel *label_2;
    QPushButton *chat;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QPushButton *deleteButton;
    QPushButton *previous;
    QPushButton *next;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(949, 669);
        messages = new QPushButton(Dialog);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(420, 60, 100, 32));
        line_9 = new QFrame(Dialog);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(130, 90, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        profile = new QPushButton(Dialog);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(700, 60, 100, 32));
        line_12 = new QFrame(Dialog);
        line_12->setObjectName("line_12");
        line_12->setGeometry(QRect(90, 630, 681, 31));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        feed = new QPushButton(Dialog);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(140, 60, 100, 32));
        label_3 = new QLabel(Dialog);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(410, 210, 121, 20));
        label_2 = new QLabel(Dialog);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(410, 170, 121, 20));
        chat = new QPushButton(Dialog);
        chat->setObjectName("chat");
        chat->setGeometry(QRect(320, 260, 83, 29));
        label_11 = new QLabel(Dialog);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(10, 100, 101, 101));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/happy_fisherman.png")));
        label_11->setScaledContents(true);
        label_12 = new QLabel(Dialog);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(10, 220, 91, 20));
        label_13 = new QLabel(Dialog);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(10, 260, 111, 20));
        deleteButton = new QPushButton(Dialog);
        deleteButton->setObjectName("deleteButton");
        deleteButton->setGeometry(QRect(490, 260, 83, 29));
        previous = new QPushButton(Dialog);
        previous->setObjectName("previous");
        previous->setGeometry(QRect(210, 210, 61, 32));
        next = new QPushButton(Dialog);
        next->setObjectName("next");
        next->setGeometry(QRect(650, 210, 61, 32));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        messages->setText(QCoreApplication::translate("Dialog", "Messages", nullptr));
        profile->setText(QCoreApplication::translate("Dialog", "Profile", nullptr));
        feed->setText(QCoreApplication::translate("Dialog", "Feed", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "@fishmeister", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "John Doe", nullptr));
        chat->setText(QCoreApplication::translate("Dialog", "Chat", nullptr));
        label_11->setText(QString());
        label_12->setText(QCoreApplication::translate("Dialog", "Salty Steve", nullptr));
        label_13->setText(QCoreApplication::translate("Dialog", "@humanefisher", nullptr));
        deleteButton->setText(QCoreApplication::translate("Dialog", "Delete", nullptr));
        previous->setText(QCoreApplication::translate("Dialog", "<", nullptr));
        next->setText(QCoreApplication::translate("Dialog", ">", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERSATIONS_H
