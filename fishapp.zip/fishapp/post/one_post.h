#ifndef ONE_POST_H
#define ONE_POST_H
#include <QString>


class one_post
{
public:
    one_post(int post_id, int author_id,
             QString title, QString content, QString timestamp);

    int return_postId();
    int return_authorId();
    QString return_title();
    QString return_content();
    QString return_timestamp();

private:
    int post_id;
    int author_id;
    QString title;
    QString content;
    QString timestamp;
};

#endif // ONE_POST_H
