/********************************************************************************
** Form generated from reading UI file 'login_user.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_USER_H
#define UI_LOGIN_USER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login_user
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *submitButton;
    QPushButton *cancelButton;
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QFormLayout *formLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLabel *label_3;
    QVBoxLayout *verticalLayout;
    QLineEdit *usernameEdit;
    QLineEdit *passwordEdit;

    void setupUi(QDialog *login_user)
    {
        if (login_user->objectName().isEmpty())
            login_user->setObjectName("login_user");
        login_user->resize(310, 210);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(login_user->sizePolicy().hasHeightForWidth());
        login_user->setSizePolicy(sizePolicy);
        login_user->setMinimumSize(QSize(310, 210));
        login_user->setMaximumSize(QSize(310, 210));
        layoutWidget = new QWidget(login_user);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(90, 140, 169, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        submitButton = new QPushButton(layoutWidget);
        submitButton->setObjectName("submitButton");

        horizontalLayout->addWidget(submitButton);

        cancelButton = new QPushButton(layoutWidget);
        cancelButton->setObjectName("cancelButton");

        horizontalLayout->addWidget(cancelButton);

        widget = new QWidget(login_user);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(50, 20, 206, 96));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName("label");
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        formLayout = new QFormLayout();
        formLayout->setObjectName("formLayout");
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_2 = new QLabel(widget);
        label_2->setObjectName("label_2");

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName("label_3");

        verticalLayout_2->addWidget(label_3);


        formLayout->setLayout(0, QFormLayout::LabelRole, verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        usernameEdit = new QLineEdit(widget);
        usernameEdit->setObjectName("usernameEdit");

        verticalLayout->addWidget(usernameEdit);

        passwordEdit = new QLineEdit(widget);
        passwordEdit->setObjectName("passwordEdit");

        verticalLayout->addWidget(passwordEdit);


        formLayout->setLayout(0, QFormLayout::FieldRole, verticalLayout);


        verticalLayout_3->addLayout(formLayout);


        retranslateUi(login_user);

        QMetaObject::connectSlotsByName(login_user);
    } // setupUi

    void retranslateUi(QDialog *login_user)
    {
        login_user->setWindowTitle(QCoreApplication::translate("login_user", "Dialog", nullptr));
        submitButton->setText(QCoreApplication::translate("login_user", "Submit", nullptr));
        cancelButton->setText(QCoreApplication::translate("login_user", "Cancel", nullptr));
        label->setText(QCoreApplication::translate("login_user", "Welcome Back, User!", nullptr));
        label_2->setText(QCoreApplication::translate("login_user", "Username", nullptr));
        label_3->setText(QCoreApplication::translate("login_user", "Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class login_user: public Ui_login_user {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_USER_H
