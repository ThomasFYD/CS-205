/****************************************************************************
** Meta object code from reading C++ file 'user_profile.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../fishapp/fishapp_ui/user_profile.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'user_profile.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSuser_profileENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSuser_profileENDCLASS = QtMocHelpers::stringData(
    "user_profile",
    "on_feed_clicked",
    "",
    "on_messages_clicked",
    "on_profile_clicked",
    "on_settings_clicked",
    "on_log_out_clicked",
    "on_previous_post_clicked",
    "on_next_post_clicked",
    "on_delete_post_clicked",
    "load_post"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSuser_profileENDCLASS_t {
    uint offsetsAndSizes[22];
    char stringdata0[13];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[19];
    char stringdata5[20];
    char stringdata6[19];
    char stringdata7[25];
    char stringdata8[21];
    char stringdata9[23];
    char stringdata10[10];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSuser_profileENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSuser_profileENDCLASS_t qt_meta_stringdata_CLASSuser_profileENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "user_profile"
        QT_MOC_LITERAL(13, 15),  // "on_feed_clicked"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 19),  // "on_messages_clicked"
        QT_MOC_LITERAL(50, 18),  // "on_profile_clicked"
        QT_MOC_LITERAL(69, 19),  // "on_settings_clicked"
        QT_MOC_LITERAL(89, 18),  // "on_log_out_clicked"
        QT_MOC_LITERAL(108, 24),  // "on_previous_post_clicked"
        QT_MOC_LITERAL(133, 20),  // "on_next_post_clicked"
        QT_MOC_LITERAL(154, 22),  // "on_delete_post_clicked"
        QT_MOC_LITERAL(177, 9)   // "load_post"
    },
    "user_profile",
    "on_feed_clicked",
    "",
    "on_messages_clicked",
    "on_profile_clicked",
    "on_settings_clicked",
    "on_log_out_clicked",
    "on_previous_post_clicked",
    "on_next_post_clicked",
    "on_delete_post_clicked",
    "load_post"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSuser_profileENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x08,    1 /* Private */,
       3,    0,   69,    2, 0x08,    2 /* Private */,
       4,    0,   70,    2, 0x08,    3 /* Private */,
       5,    0,   71,    2, 0x08,    4 /* Private */,
       6,    0,   72,    2, 0x08,    5 /* Private */,
       7,    0,   73,    2, 0x08,    6 /* Private */,
       8,    0,   74,    2, 0x08,    7 /* Private */,
       9,    0,   75,    2, 0x08,    8 /* Private */,
      10,    0,   76,    2, 0x08,    9 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject user_profile::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSuser_profileENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSuser_profileENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSuser_profileENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<user_profile, std::true_type>,
        // method 'on_feed_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_messages_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_profile_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_settings_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_log_out_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_previous_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_next_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_delete_post_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'load_post'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void user_profile::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<user_profile *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_feed_clicked(); break;
        case 1: _t->on_messages_clicked(); break;
        case 2: _t->on_profile_clicked(); break;
        case 3: _t->on_settings_clicked(); break;
        case 4: _t->on_log_out_clicked(); break;
        case 5: _t->on_previous_post_clicked(); break;
        case 6: _t->on_next_post_clicked(); break;
        case 7: _t->on_delete_post_clicked(); break;
        case 8: _t->load_post(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *user_profile::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *user_profile::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSuser_profileENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int user_profile::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
