/********************************************************************************
** Form generated from reading UI file 'conversation.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERSATION_H
#define UI_CONVERSATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>

QT_BEGIN_NAMESPACE

class Ui_conversation
{
public:
    QFrame *line_12;
    QScrollBar *verticalScrollBar;
    QFrame *line_11;
    QPushButton *messages;
    QPushButton *other_user;
    QFrame *line_9;
    QFrame *line_10;
    QGraphicsView *profile_picture;
    QGraphicsView *profile_picture_2;
    QLabel *message;
    QGraphicsView *profile_picture_3;
    QLabel *message_2;
    QLabel *message_3;
    QGraphicsView *profile_picture_4;
    QLabel *message_4;
    QGraphicsView *profile_picture_5;
    QLabel *message_5;

    void setupUi(QDialog *conversation)
    {
        if (conversation->objectName().isEmpty())
            conversation->setObjectName("conversation");
        conversation->resize(904, 624);
        line_12 = new QFrame(conversation);
        line_12->setObjectName("line_12");
        line_12->setGeometry(QRect(140, 590, 681, 31));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        verticalScrollBar = new QScrollBar(conversation);
        verticalScrollBar->setObjectName("verticalScrollBar");
        verticalScrollBar->setGeometry(QRect(140, 69, 20, 531));
        verticalScrollBar->setOrientation(Qt::Vertical);
        line_11 = new QFrame(conversation);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(820, 0, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        messages = new QPushButton(conversation);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(150, 20, 100, 32));
        other_user = new QPushButton(conversation);
        other_user->setObjectName("other_user");
        other_user->setGeometry(QRect(430, 20, 100, 32));
        line_9 = new QFrame(conversation);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(140, 50, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        line_10 = new QFrame(conversation);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(140, 0, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        profile_picture = new QGraphicsView(conversation);
        profile_picture->setObjectName("profile_picture");
        profile_picture->setGeometry(QRect(170, 90, 51, 51));
        profile_picture_2 = new QGraphicsView(conversation);
        profile_picture_2->setObjectName("profile_picture_2");
        profile_picture_2->setGeometry(QRect(760, 210, 51, 51));
        message = new QLabel(conversation);
        message->setObjectName("message");
        message->setGeometry(QRect(230, 140, 291, 31));
        profile_picture_3 = new QGraphicsView(conversation);
        profile_picture_3->setObjectName("profile_picture_3");
        profile_picture_3->setGeometry(QRect(170, 310, 51, 51));
        message_2 = new QLabel(conversation);
        message_2->setObjectName("message_2");
        message_2->setGeometry(QRect(230, 360, 291, 31));
        message_3 = new QLabel(conversation);
        message_3->setObjectName("message_3");
        message_3->setGeometry(QRect(470, 260, 291, 31));
        profile_picture_4 = new QGraphicsView(conversation);
        profile_picture_4->setObjectName("profile_picture_4");
        profile_picture_4->setGeometry(QRect(170, 400, 51, 51));
        message_4 = new QLabel(conversation);
        message_4->setObjectName("message_4");
        message_4->setGeometry(QRect(230, 450, 291, 31));
        profile_picture_5 = new QGraphicsView(conversation);
        profile_picture_5->setObjectName("profile_picture_5");
        profile_picture_5->setGeometry(QRect(170, 500, 51, 51));
        message_5 = new QLabel(conversation);
        message_5->setObjectName("message_5");
        message_5->setGeometry(QRect(230, 550, 291, 31));

        retranslateUi(conversation);

        QMetaObject::connectSlotsByName(conversation);
    } // setupUi

    void retranslateUi(QDialog *conversation)
    {
        conversation->setWindowTitle(QCoreApplication::translate("conversation", "Dialog", nullptr));
        messages->setText(QCoreApplication::translate("conversation", "Messages", nullptr));
        other_user->setText(QCoreApplication::translate("conversation", "User", nullptr));
        message->setText(QCoreApplication::translate("conversation", "message", nullptr));
        message_2->setText(QCoreApplication::translate("conversation", "message", nullptr));
        message_3->setText(QCoreApplication::translate("conversation", "message", nullptr));
        message_4->setText(QCoreApplication::translate("conversation", "message", nullptr));
        message_5->setText(QCoreApplication::translate("conversation", "message", nullptr));
    } // retranslateUi

};

namespace Ui {
    class conversation: public Ui_conversation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERSATION_H
