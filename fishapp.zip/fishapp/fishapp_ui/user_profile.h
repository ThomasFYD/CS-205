#ifndef USER_PROFILE_H
#define USER_PROFILE_H

#include <QDialog>
#include "../post/one_post.h"
#include "../post/upload.h"
#include "QtWidgets/qmainwindow.h"

namespace Ui {
class user_profile;
}

class user_profile : public QDialog
{
    Q_OBJECT

public:
    explicit user_profile(QMainWindow* mainWindow, QWidget *parent,  auth_manager& userAuthenticaiton);
    ~user_profile();

private slots:
    void on_feed_clicked();

    void on_messages_clicked();

    void on_profile_clicked();

    void on_settings_clicked();

    void on_log_out_clicked();

    void on_previous_post_clicked();

    void on_next_post_clicked();

    void on_delete_post_clicked();

    void load_post();

private:
    Ui::user_profile *ui;
    std::vector<one_post> myPosts;
    user* currentUser;
    int position;
    auth_manager& myManager;
    upload myUpload;
    QMainWindow* mainWindow;
};

#endif // USER_PROFILE_H
