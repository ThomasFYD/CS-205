#include "auth_manager.h"
#include <iostream>

using namespace std;

int main()
{
//    db_access myDb;
//    auth_manager myManager(myDb);

//    myManager.createUser("Ado", "Andria", "Saneblidze",
//                         "adobado@gmail.com", QDate::currentDate().toString(), "adobado555", -1);

//    myManager.createUser("Ado2", "Andria2", "Saneblidze2",
//                         "adobado2@gmail.com", QDate::currentDate().toString(), "adobado555", 1000);

//    if (myManager.authenticate("Ado", "adobado555")){
//        cout << "Yay!";
//    }else{
//        cout << "Naaah!";
//    }

//    cout << myManager.getCurrentUser()->getId() << endl;
//    cout << myManager.getCurrentUser()->getFirstName().toStdString() << endl;
//    cout << myManager.getCurrentUser()->getLastName().toStdString() << endl;
//    cout << myManager.getCurrentUser()->getDateOfRegistration().toStdString() << endl;

////    myManager.changePassword("Aelere", "newLasha123");

////    if (myManager.authenticate("Aelere", "newLasha123")){
////        cout << "Yay!";
////    }else{
////        cout << "Naaah!";
////    }

//    if (myManager.authenticate("Ado2", "adobado555")){
//        cout << "Yay!";
//    }else{
//        cout << "Naaaah!";
//    }

//    cout << myManager.getCurrentUser()->getId() << endl;
//    cout << myManager.getCurrentUser()->getFirstName().toStdString() << endl;
//    cout << myManager.getCurrentUser()->getLastName().toStdString() << endl;
//    cout << myManager.getCurrentUser()->getDateOfRegistration().toStdString() << endl;


}
