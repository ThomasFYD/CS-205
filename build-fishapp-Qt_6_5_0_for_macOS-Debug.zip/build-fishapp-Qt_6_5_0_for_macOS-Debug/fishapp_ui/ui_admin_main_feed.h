/********************************************************************************
** Form generated from reading UI file 'admin_main_feed.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_MAIN_FEED_H
#define UI_ADMIN_MAIN_FEED_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QFrame *line_4;
    QFrame *line_2;
    QLabel *label_10;
    QLabel *label;
    QFrame *line_9;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QFrame *line_6;
    QLabel *label_6;
    QPushButton *report_2;
    QPushButton *pushButton;
    QLabel *label_14;
    QFrame *line_5;
    QLabel *label_15;
    QLabel *label_3;
    QFrame *line_11;
    QPushButton *report;
    QPushButton *feed;
    QLabel *label_7;
    QPushButton *pushButton_5;
    QFrame *line_10;
    QPushButton *messages;
    QLabel *label_4;
    QFrame *line;
    QPushButton *profile;
    QTextEdit *content;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_8;
    QFrame *line_7;
    QTextEdit *content_2;
    QLabel *label_9;
    QFrame *line_3;
    QPushButton *pushButton_4;
    QScrollBar *scroll;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(912, 654);
        line_4 = new QFrame(Dialog);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(140, 390, 20, 281));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(Dialog);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(150, 350, 611, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        label_10 = new QLabel(Dialog);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(670, 440, 71, 20));
        label = new QLabel(Dialog);
        label->setObjectName("label");
        label->setGeometry(QRect(160, 80, 71, 61));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/4f02e903d4e76b458f3e663405a51679.jpg")));
        label->setScaledContents(true);
        line_9 = new QFrame(Dialog);
        line_9->setObjectName("line_9");
        line_9->setGeometry(QRect(130, 50, 681, 31));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        pushButton_3 = new QPushButton(Dialog);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(820, 610, 83, 29));
        pushButton_2 = new QPushButton(Dialog);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(10, 270, 111, 29));
        line_6 = new QFrame(Dialog);
        line_6->setObjectName("line_6");
        line_6->setGeometry(QRect(750, 390, 20, 281));
        line_6->setFrameShape(QFrame::VLine);
        line_6->setFrameShadow(QFrame::Sunken);
        label_6 = new QLabel(Dialog);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(160, 400, 71, 61));
        label_6->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/joke-fishing-funny-fishing-mens-t-shirt.jpg")));
        label_6->setScaledContents(true);
        report_2 = new QPushButton(Dialog);
        report_2->setObjectName("report_2");
        report_2->setGeometry(QRect(660, 400, 91, 31));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../database/pictures/1045119-200.png"), QSize(), QIcon::Normal, QIcon::Off);
        report_2->setIcon(icon);
        pushButton = new QPushButton(Dialog);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(10, 220, 111, 29));
        label_14 = new QLabel(Dialog);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(240, 130, 191, 20));
        line_5 = new QFrame(Dialog);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(750, 80, 20, 281));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        label_15 = new QLabel(Dialog);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(240, 440, 191, 20));
        label_3 = new QLabel(Dialog);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(240, 110, 121, 20));
        line_11 = new QFrame(Dialog);
        line_11->setObjectName("line_11");
        line_11->setGeometry(QRect(810, 0, 3, 61));
        line_11->setFrameShape(QFrame::VLine);
        line_11->setFrameShadow(QFrame::Sunken);
        report = new QPushButton(Dialog);
        report->setObjectName("report");
        report->setGeometry(QRect(660, 90, 91, 31));
        report->setIcon(icon);
        feed = new QPushButton(Dialog);
        feed->setObjectName("feed");
        feed->setGeometry(QRect(140, 20, 100, 32));
        label_7 = new QLabel(Dialog);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(180, 459, 531, 41));
        QFont font;
        font.setPointSize(16);
        label_7->setFont(font);
        pushButton_5 = new QPushButton(Dialog);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(880, 10, 31, 29));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../database/pictures/Ic_settings_48px.svg.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon1);
        pushButton_5->setCheckable(false);
        line_10 = new QFrame(Dialog);
        line_10->setObjectName("line_10");
        line_10->setGeometry(QRect(130, 0, 3, 61));
        line_10->setFrameShape(QFrame::VLine);
        line_10->setFrameShadow(QFrame::Sunken);
        messages = new QPushButton(Dialog);
        messages->setObjectName("messages");
        messages->setGeometry(QRect(420, 20, 100, 32));
        label_4 = new QLabel(Dialog);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(180, 150, 441, 41));
        label_4->setFont(font);
        line = new QFrame(Dialog);
        line->setObjectName("line");
        line->setGeometry(QRect(150, 70, 611, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        profile = new QPushButton(Dialog);
        profile->setObjectName("profile");
        profile->setGeometry(QRect(700, 20, 100, 32));
        content = new QTextEdit(Dialog);
        content->setObjectName("content");
        content->setGeometry(QRect(180, 190, 551, 161));
        label_2 = new QLabel(Dialog);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(240, 90, 121, 20));
        label_5 = new QLabel(Dialog);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(670, 130, 71, 20));
        label_8 = new QLabel(Dialog);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(240, 400, 111, 20));
        line_7 = new QFrame(Dialog);
        line_7->setObjectName("line_7");
        line_7->setGeometry(QRect(150, 380, 611, 16));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);
        content_2 = new QTextEdit(Dialog);
        content_2->setObjectName("content_2");
        content_2->setGeometry(QRect(180, 500, 551, 161));
        label_9 = new QLabel(Dialog);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(240, 420, 131, 20));
        line_3 = new QFrame(Dialog);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(140, 80, 20, 281));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        pushButton_4 = new QPushButton(Dialog);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(10, 310, 111, 29));
        scroll = new QScrollBar(Dialog);
        scroll->setObjectName("scroll");
        scroll->setGeometry(QRect(790, 60, 16, 701));
        scroll->setOrientation(Qt::Vertical);
        pushButton_6 = new QPushButton(Dialog);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(570, 400, 83, 29));
        pushButton_7 = new QPushButton(Dialog);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(480, 90, 83, 29));
        pushButton_8 = new QPushButton(Dialog);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(470, 400, 83, 29));
        pushButton_9 = new QPushButton(Dialog);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(570, 90, 83, 29));
        label_11 = new QLabel(Dialog);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(10, 120, 63, 20));
        label_12 = new QLabel(Dialog);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(10, 90, 63, 20));
        label_13 = new QLabel(Dialog);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(10, 20, 63, 61));
        label_13->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/admin-sign-laptop-icon-stock-vector-166205404.jpg")));
        label_13->setScaledContents(true);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        label_10->setText(QCoreApplication::translate("Dialog", "4/16/2023", nullptr));
        label->setText(QString());
        pushButton_3->setText(QCoreApplication::translate("Dialog", "Log Out", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dialog", "Search Interests", nullptr));
        label_6->setText(QString());
        report_2->setText(QCoreApplication::translate("Dialog", "Report", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog", "View Reports", nullptr));
        label_14->setText(QCoreApplication::translate("Dialog", "Interests: Stillwater, Fishing", nullptr));
        label_15->setText(QCoreApplication::translate("Dialog", "Interests: Stillwater, Fishing", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "@fishmeister", nullptr));
        report->setText(QCoreApplication::translate("Dialog", "Report", nullptr));
        feed->setText(QCoreApplication::translate("Dialog", "Feed", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog", "The One that Got Away: My Friend's Failure", nullptr));
        pushButton_5->setText(QString());
        messages->setText(QCoreApplication::translate("Dialog", "Messages", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog", "I Caught the Biggest Fish in the Lake!", nullptr));
        profile->setText(QCoreApplication::translate("Dialog", "Profile", nullptr));
        content->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">I spent hours casting and reeling, determined to catch the biggest fish in the lake. My friends teased me, saying it was impossible, but I refused to give up. Finally, I felt a strong pull on my line and after a long battle, I pulled in a massive bass - easily the largest fish in the lake. My friends were amazed and I basked in the glory of my accomplishment, knowing that I had truly become a master f"
                        "isherman.</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#00aaff;\">#bestdayofmylife #bass #record #winner</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "John Doe", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog", "4/16/2023", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog", "Bob Bait", nullptr));
        content_2->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">One day, my friend and I went out on the lake for a day of fishing. As we cast our lines, I couldn't help but notice that my friend seemed to be struggling. He kept losing bait, getting tangled in his line, and even managed to hook himself at one point. It was a tough day for him, but we both laughed it off and enjoyed the experience nonetheless. Even though he didn't catch anything, we still had a gr"
                        "eat time and made some unforgettable memories on the water.</p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog", "@CaptainJack17", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Dialog", "Search Hashtags", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Dialog", "Delete Post", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Dialog", "Ban User", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Dialog", "Ban User", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Dialog", "Delete Post", nullptr));
        label_11->setText(QCoreApplication::translate("Dialog", "Lasha", nullptr));
        label_12->setText(QCoreApplication::translate("Dialog", "Admin 2", nullptr));
        label_13->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_MAIN_FEED_H
