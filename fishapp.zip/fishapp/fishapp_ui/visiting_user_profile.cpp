#include "visiting_user_profile.h"
#include "ui_visiting_user_profile.h"

visiting_user_profile::visiting_user_profile(QMainWindow* mainWindow, QWidget *parent,  auth_manager& userAuthenticaiton, int other_user_id) :
    QMainWindow(parent),
    ui(new Ui::visiting_user_profile),
    currentUser(userAuthenticaiton.getCurrentUser()),
    myManager(userAuthenticaiton),
    myUpload(myManager),
    mainWindow(mainWindow),
    otherUser(myUpload.getOtherUser(other_user_id))
{
    ui->setupUi(this);
    ui->user_username->setText("@" + otherUser->getUsername());
    ui->user_fullname->setText(otherUser->getFirstName() + " " + otherUser->getLastName());
}

visiting_user_profile::~visiting_user_profile()
{
    delete ui;
}

void visiting_user_profile::on_report_post_clicked()
{

}


void visiting_user_profile::on_previous_post_clicked()
{

}


void visiting_user_profile::on_next_post_clicked()
{

}


void visiting_user_profile::on_log_out_clicked()
{

}


void visiting_user_profile::on_conversation_clicked()
{

}


void visiting_user_profile::on_messages_clicked()
{

}


void visiting_user_profile::on_feed_clicked()
{

}


void visiting_user_profile::on_profile_clicked()
{

}

