#ifndef UPLOAD_H
#define UPLOAD_H
#include "string"
#include "../authentication_engine/auth_manager.h"
#include "../authentication_engine/user.h"
#include "one_post.h"
#include "QtSql/qsqlerror.h"
#include "QtSql/qsqlquery.h"
#include <iomanip>
#include <ctime>
#include <sstream>


class upload
{
public:
    upload(auth_manager& userAuthentication);//db_access& dbAccess, user& userAccess);
    bool send(std::string title, std::string content, std::vector<std::string> hashtags);
    std::vector<one_post> findPosts();
    std::vector<one_post> other_findPosts(int user_id);
    bool report_post(int post_id, std::string reason);
    bool remove_post(int post_id, int moderator_id, std::string removal_reason);
    bool delete_post(int post_id);
    std::vector<std::string> find_hashtags();
    std::vector<std::string> findInformation(int postId);
    user* getOtherUser(int user_id);

    //~upload();
private:
//    db_access& m_dbAccess;
//    user& myUser;
    auth_manager& myAuthentication;
};

#endif // UPLOAD_H
