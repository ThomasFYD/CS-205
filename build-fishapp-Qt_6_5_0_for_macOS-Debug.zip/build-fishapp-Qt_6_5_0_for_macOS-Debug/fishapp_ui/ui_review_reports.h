/********************************************************************************
** Form generated from reading UI file 'review_reports.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REVIEW_REPORTS_H
#define UI_REVIEW_REPORTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>

QT_BEGIN_NAMESPACE

class Ui_review_reports
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QScrollBar *verticalScrollBar;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;

    void setupUi(QDialog *review_reports)
    {
        if (review_reports->objectName().isEmpty())
            review_reports->setObjectName("review_reports");
        review_reports->resize(665, 490);
        pushButton = new QPushButton(review_reports);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(120, 190, 101, 29));
        pushButton_2 = new QPushButton(review_reports);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(240, 190, 101, 29));
        pushButton_3 = new QPushButton(review_reports);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(360, 190, 91, 29));
        pushButton_4 = new QPushButton(review_reports);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(470, 190, 83, 29));
        label = new QLabel(review_reports);
        label->setObjectName("label");
        label->setGeometry(QRect(120, 80, 111, 20));
        label_2 = new QLabel(review_reports);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(120, 110, 171, 20));
        label_3 = new QLabel(review_reports);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(400, 80, 151, 20));
        label_4 = new QLabel(review_reports);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(120, 140, 271, 20));
        line = new QFrame(review_reports);
        line->setObjectName("line");
        line->setGeometry(QRect(80, 80, 16, 401));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(review_reports);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(583, 80, 20, 411));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(review_reports);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(80, 70, 521, 16));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(review_reports);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(90, 240, 501, 16));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        verticalScrollBar = new QScrollBar(review_reports);
        verticalScrollBar->setObjectName("verticalScrollBar");
        verticalScrollBar->setGeometry(QRect(580, 80, 16, 401));
        verticalScrollBar->setOrientation(Qt::Vertical);
        label_5 = new QLabel(review_reports);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(10, 20, 63, 61));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../../database/pictures/admin-sign-laptop-icon-stock-vector-166205404.jpg")));
        label_5->setScaledContents(true);
        label_6 = new QLabel(review_reports);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(10, 90, 63, 20));
        label_7 = new QLabel(review_reports);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(10, 120, 63, 20));
        pushButton_5 = new QPushButton(review_reports);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(110, 30, 83, 29));
        pushButton_6 = new QPushButton(review_reports);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(290, 30, 83, 29));
        pushButton_7 = new QPushButton(review_reports);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(490, 30, 83, 29));
        pushButton_8 = new QPushButton(review_reports);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(0, 440, 83, 29));

        retranslateUi(review_reports);

        QMetaObject::connectSlotsByName(review_reports);
    } // setupUi

    void retranslateUi(QDialog *review_reports)
    {
        review_reports->setWindowTitle(QCoreApplication::translate("review_reports", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("review_reports", "Remove Post", nullptr));
        pushButton_2->setText(QCoreApplication::translate("review_reports", "Ban User", nullptr));
        pushButton_3->setText(QCoreApplication::translate("review_reports", "Shadowban", nullptr));
        pushButton_4->setText(QCoreApplication::translate("review_reports", "Suspend", nullptr));
        label->setText(QCoreApplication::translate("review_reports", "ReportID  15", nullptr));
        label_2->setText(QCoreApplication::translate("review_reports", "Reason: Hate Speech", nullptr));
        label_3->setText(QCoreApplication::translate("review_reports", "Username: @fisheater", nullptr));
        label_4->setText(QCoreApplication::translate("review_reports", "Post: I hate fish with a burning passion!", nullptr));
        label_5->setText(QString());
        label_6->setText(QCoreApplication::translate("review_reports", "Admin 2", nullptr));
        label_7->setText(QCoreApplication::translate("review_reports", "Lasha", nullptr));
        pushButton_5->setText(QCoreApplication::translate("review_reports", "Feed", nullptr));
        pushButton_6->setText(QCoreApplication::translate("review_reports", "Reports", nullptr));
        pushButton_7->setText(QCoreApplication::translate("review_reports", "PushButton", nullptr));
        pushButton_8->setText(QCoreApplication::translate("review_reports", "Logout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class review_reports: public Ui_review_reports {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REVIEW_REPORTS_H
