/********************************************************************************
** Form generated from reading UI file 'user_interest.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USER_INTEREST_H
#define UI_USER_INTEREST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>

QT_BEGIN_NAMESPACE

class Ui_user_interest
{
public:
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *user_interest)
    {
        if (user_interest->objectName().isEmpty())
            user_interest->setObjectName("user_interest");
        user_interest->resize(400, 300);
        buttonBox = new QDialogButtonBox(user_interest);
        buttonBox->setObjectName("buttonBox");
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        retranslateUi(user_interest);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, user_interest, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, user_interest, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(user_interest);
    } // setupUi

    void retranslateUi(QDialog *user_interest)
    {
        user_interest->setWindowTitle(QCoreApplication::translate("user_interest", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class user_interest: public Ui_user_interest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USER_INTEREST_H
